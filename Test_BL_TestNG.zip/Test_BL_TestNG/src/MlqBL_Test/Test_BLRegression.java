package MlqBL_Test;

import Global_Function_Lib.Excel_Data;
import Global_Function_Lib.Utility;
import MlqBl_Page.BlRegressionPage;
import MlqBL_AppModule.Action;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Test_BLRegression {

	static String stateSelected;
	static String releaseWeek;
	static int earFlag = 0;
	static String executionFlag = "";
	static String releaseDate = "";
	static String impersonateUrlsLink = "";
	static String wasServer = "";
	static String productFlag;
	static String productTypeInError;
	static String earToSelect = "";
	static String earSelected = "";
	static boolean ear = false;
	static String state;
	static String impersonateUrlOfPresentWasServer = "";
	static int presentProductFlag = 0;
	static String[] errorCodes;
	static String filePath = null;
	static boolean isAlreadyRaised = false;
	static int testCaseNumber;
	static int totalTestCases;
	static String testCaseSelect;
	static int totalRows;
	static String dcUrl = "";
	static int num;
	String testCase;

	@Parameters({"testCases"})
	@Factory
	public Object[] createClassInstance(int testCases) {       
		Object[] instance = new Object[testCases];
		for (int i = 0; i < testCases; i++) {
			instance[i] = new Test_BLRegression();
		}
		return instance;
	}

	@BeforeSuite
	// **** below code use the .properties file for reading the data ********
	public void fileReader() {

		try {
			Properties prop = new Properties();
			String propFilename = "configs//Configuration.properties";
			InputStream inputStream = new FileInputStream(propFilename);

			if (inputStream != null) {
				prop.load(inputStream);
			}

			impersonateUrlsLink = prop.getProperty("ImpURL");
			filePath = prop.getProperty("FilePath");
			dcUrl = prop.getProperty("DCUrl");
			totalTestCases = Excel_Data.getExcelRows(0, filePath);
			

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}
	}
	@Parameters({"startTestCases"})
	@BeforeTest
	public void selectTheTestCase(int startTestCases){
		testCaseNumber = startTestCases;
	}
	@Parameters({"executionMode","compareMode"})
	@BeforeMethod
	public void selectTheExecutionMode(String executionMode, String compareMode) throws Exception{
		Action.ieSetUp();
		Action.launchTheDCWorkstationURL(dcUrl);
		try {			
            
			if(testCaseNumber < 10){
				testCase = "TC_0";
			}
			else if(testCaseNumber >= 10){
				testCase = "TC_";
			}
	           
			
			String date = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "ReleaseDate", filePath);
			releaseDate = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4, 8);
			wasServer = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "WasServer", filePath);
	/*		String errors = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "ErrorCodes", filePath);
			errorCodes = errors.split(",");*/
			executionFlag = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "ExecutionFlag", filePath);
			productFlag = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "ProductFlag", filePath);
			releaseWeek = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "ReleaseWeek", filePath);
			//testCaseSelect = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "TestCaseExecute", filePath);
		} catch (Exception e) {
			System.out.println(e);
		}
		BlRegressionPage.admin(Action.driverIE).click();
		BlRegressionPage.configurationProperties(Action.driverIE).click();
		for(int i=0 ; i<BlRegressionPage.compareMode(Action.driverIE).size() ; i++ ){
			
			if(BlRegressionPage.compareMode(Action.driverIE).get(i).getAttribute("onclick").contains(compareMode)){
				//System.out.println((BlRegressionPage.compareMode(Action.driverIE).get(i).getText()));
				//System.out.println("value of i :" + i);
				BlRegressionPage.compareMode(Action.driverIE).get(i).click();
				break;
			}
		}
		BlRegressionPage.modeValue(Action.driverIE).clear();
		BlRegressionPage.modeValue(Action.driverIE).sendKeys(executionMode);
		BlRegressionPage.saveProperty(Action.driverIE).click();
		
	}
	
	@AfterMethod
	public void checkForTheUrlUp() throws InterruptedException{
		Date date = new Date();
		System.out.println("Execution Finished at : " + date.toString());
		System.out.println("Test Case " + testCase + (testCaseNumber -1)  + " got Executed");
		Action.tearDownIE();
	}
	
/*	@Test
	public void testing(){
		System.out.println("Tested");
		testCaseNumber++;
		System.out.println("ascnmac  " + testCaseNumber);
	}*/
	@Parameters({"productType"})
	@Test 
	public static void validateTheImpersonateURLAndLaunchDCWorkstation(String productType) {

			try {
				BlRegressionPage.blRegressionTabElement(Action.driverIE).click();
				BlRegressionPage.presentReleaseDate(Action.driverIE).selectByValue(releaseDate);
				//Action.selectTheTransactionType(BlRegressionPage.transactionTypeElement(Action.driverIE));
				BlRegressionPage.transactionType(Action.driverIE).selectByValue(productType);
				Action.selectTheRecordRange(BlRegressionPage.recordRangeElement(Action.driverIE));
				Action.clearTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE));
				Action.clearTheSearchBox(BlRegressionPage.search(Action.driverIE));
				BlRegressionPage.regressionServer(Action.driverIE).selectByValue("https://lxv3102.allstate.com:21143");
				BlRegressionPage.releaseWeek(Action.driverIE).selectByValue(releaseWeek);
				BlRegressionPage.regressionReleaseWeek(Action.driverIE).selectByValue(releaseWeek);
				presentProductFlag = Integer.parseInt(productFlag);
				earSelected = Action.selectTheExecutionFlagGetThePresentEAR(Integer.parseInt(executionFlag),
						presentProductFlag, earToSelect, impersonateUrlOfPresentWasServer);
				//ear = Action.checkForTheEAR(earSelected, earFlag);
				//if (ear == true) {

					switch (Integer.parseInt(executionFlag)) {
					case 0:
						Action.selectTheProductTypeExecution(presentProductFlag, releaseWeek);
						boolean status = Action.checkForTheBlankStatus();
						//int num = Action.checkBlank();
						if (status == true) {
						//if (num >= 1) {
							do {
								stateSelected = Action.selectTheStatesForExecution();		
								System.out.println("Start the Execution of Policies for State : " + stateSelected);
								//Action.policyExecutorBlock(num);
								Action.policyExecutorBlock();
								//Utility.captureScreenshot(Action.driverIE, state + "_");
								Thread.sleep(1000);
								BlRegressionPage.clearStateFilter(Action.driverIE).click();
								//System.out.println("Execution of Policies for State : " + stateSelected + " is completed");
								status = Action.checkForTheBlankStatus();
								//num = Action.checkBlank();
							} while (status == true);
							//} while (num >=1);
						}
						BlRegressionPage.clearProductTypeFilter(Action.driverIE);
						testCaseNumber++;			
						break;
						
					case 1:
						Action.selectTheProductTypeExecution(presentProductFlag, releaseWeek);
						Action.policyInErrorExecutorBlock();
						BlRegressionPage.clearProductTypeFilter(Action.driverIE);
						testCaseNumber++;						
					}

			 /*else if (ear == false) {
					testCaseNumber++;
				}*/
			} catch (Exception ex) {
				System.out.println(ex);			
				testCaseNumber++;
			}
	}	
}
