package MlqBL_Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Global_Function_Lib.Excel_Data;

public class Filter_Already_Analyzed {

	static String filePath = null;
	static String downloadPath = null;

	@BeforeSuite
	// **** below code use the .properties file for reading the data ****
	public void fileReader() {

		try {
			Properties prop = new Properties();
			String propFilename = "configs//Configuration.properties";
			InputStream inputStream = new FileInputStream(propFilename);

			if (inputStream != null) {
				prop.load(inputStream);
			}

			filePath = prop.getProperty("FilePath");
			downloadPath = prop.getProperty("ControlNumbersPath");

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}
	}

	@Test
	public static void filterAlreadyAnalyzed() throws Exception {
		List<Integer> m = new ArrayList<Integer>();
		List<String> cols = new ArrayList<String>();
		cols.add("OM Path Version 1");
		cols.add("OM Path Version 2");
		cols.add("OM Data Version 1");
		cols.add("OM Data Version 2");
		cols.add("Match");
		cols.add("Issue Type");
		List<String> controlNumbers = new ArrayList<String>();
		List<String> productFlag = new ArrayList<String>();
		List<String> productType = new ArrayList<String>();
		controlNumbers = Excel_Data.getTheExcelData(0, "ControlNumbers", filePath);
		System.out.println(controlNumbers);
		productFlag = Excel_Data.getTheExcelData(0, "ProductFlag", filePath);
		productType = Excel_Data.getTheExcelData(0, "ProductType", filePath);
		String[] regex = { "[^[0-9]]", "\\[", "\\]", "\\.\\." };
		for (int i = 0; i < controlNumbers.size(); i++) {
         
			 if(!controlNumbers.get(i).equals("")){
				ArrayList<String> omPath1 = new ArrayList<String>();
				ArrayList<String> newOmPath1 = new ArrayList<String>();
				ArrayList<String> omPath1Reference = new ArrayList<String>();
				ArrayList<String> omPath2 = new ArrayList<String>();
				ArrayList<String> omData1 = new ArrayList<String>();
				ArrayList<String> omData2 = new ArrayList<String>();
				ArrayList<String> match = new ArrayList<String>();
				ArrayList<String> issueType = new ArrayList<String>();
				ArrayList<ArrayList<String>> pending = new ArrayList<ArrayList<String>>();
				omPath1 = (ArrayList<String>) Excel_Data.getTheExcelData(0, "OM Path Version 1",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
				// System.out.println(omPath1.size());
				omPath1Reference = (ArrayList<String>) Excel_Data.getTheExcelData(Integer.parseInt(productFlag.get(i)),
						"OM Path Version 1", downloadPath + "\\MapperUtility.xlsx");
				// System.out.println(omPath1Reference.size());
				omPath2 = (ArrayList<String>) Excel_Data.getTheExcelData(0, "OM Path Version 2",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
			   // System.out.println(omPath2.size());
				omData1 = (ArrayList<String>) Excel_Data.getTheExcelData(0, "OM Data Version 1",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
				 System.out.println(omData1.size());
				// System.out.println(omData1);
				omData2 = (ArrayList<String>) Excel_Data.getTheExcelData(0, "OM Data Version 2",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
				 //System.out.println(omData2.size());
				match = (ArrayList<String>) Excel_Data.getTheExcelData(0, "Match",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
				// System.out.println(match.size());
				issueType = (ArrayList<String>) Excel_Data.getTheExcelData(0, "Issue Type",
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
                
				for (int j = 0; j < omPath1.size(); j++) {
					for (int k = 0; k < omPath1Reference.size(); k++) {
						String newOMPath1 = omPath1.get(j).replaceAll(regex[0], "").replaceAll(regex[1], "")
								.replaceAll(regex[2], "").replaceAll(regex[3], ".");
						String newOmPath1Reference = omPath1Reference.get(k).replaceAll(regex[0], "")
								.replaceAll(regex[1], "").replaceAll(regex[2], "").replaceAll(regex[3], ".");
						if (newOMPath1.equals(newOmPath1Reference)) {
						/*if (newOMPath1.equals(newOmPath1Reference) && j != 0 && k !=0) {*/
							/*
							 * if( j< 10){ System.out.println(newOMPath1);
							 * System.out.println(newOmPath1Reference);
							 * System.out.println(omPath1.get(j));
							 * System.out.println(omPath1Reference.get(k)); }
							 */					
							m.add(j);
							break;
						}
					}
				}
               System.out.println(m.size());
				for (int j = 0; j < m.size(); j++) {
					omPath1.remove(m.get(j) - j);
					omPath2.remove(m.get(j) - j);
					omData1.remove(m.get(j) - j);
					omData2.remove(m.get(j) - j);
					match.remove(m.get(j) - j);
					issueType.remove(m.get(j) - j);
				}
				pending.add(omPath1);
				pending.add(omPath2);
				pending.add(omData1);
				pending.add(omData2);
				pending.add(match);
				pending.add(issueType);
				//System.out.println("sdjvbnsjdvbsjdvb " + m.size());
				Excel_Data.setColorToCell(0, 1, m,
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");
				Excel_Data.writeExcelData(0, "PendingAnalysis", cols, pending,
						downloadPath + "\\" + productType.get(i) + "\\" + controlNumbers.get(i).toString() + ".xlsx");

				System.out.println("done");
				newOmPath1.clear();
				omPath2.clear();
				omData1.clear();
				omData2.clear();
				match.clear();
				issueType.clear();
				m.clear();
			 }
			}
		}
	}

