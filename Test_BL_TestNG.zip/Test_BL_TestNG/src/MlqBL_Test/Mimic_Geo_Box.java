package MlqBL_Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import Global_Function_Lib.Excel_Data;
import MlqBL_AppModule.Action;
import MlqBl_Page.BlRegressionPage;

public class Mimic_Geo_Box {

	static String releaseWeek;
	static String executionFlag = "";
	static String releaseDate = "";
	static String mimicLink = "";
	static String wasServer = "";
	static String productFlag;
	static String state;
	static String impersonateUrlOfPresentWasServer = "";
	static int presentProductFlag = 0;
	static String filePath = null;
	static String downloadPath = null;
	static boolean isAlreadyRaised = false;
	static int testCaseNumber = 1;
	static int totalTestCases;
	static String testCaseSelect;
	static int totalRows;
	static int tcRows;
	static String userName;
	static String password;
	static String request;
	static String policiesFile = null;
	static String testCase = "";
	static String executionMode = "";

	@Factory
	public Object[] createClassInstance() {
		//tcRows = Excel_Data.getExcelRows(0, "C:\\Users\\mlatw\\Desktop\\Test_Data_BLRegression.xlsx");
		Object[] instance = new Object[100];
		//tcRows = Excel_Data.getExcelRows(0, "C:\\Users\\mlatw\\Desktop\\Test_Data_BLRegression.xlsx");
		//System.out.println("dakjfbakhbdfb " + tcRows);
		for (int i = 0; i <100; i++) {
			//System.out.println("dakjfbakhbdfb " + i);
			instance[i] = new Mimic_Geo_Box();
		}
		return instance;
	}

	@BeforeSuite
	// **** below code use the .properties file for reading the data ********
	public void fileReader() throws Exception {

		try {
			Properties prop = new Properties();
			String propFilename = "configs//Configuration.properties";
			InputStream inputStream = new FileInputStream(propFilename);

			if (inputStream != null) {
				prop.load(inputStream);
			}

			mimicLink = prop.getProperty("mimicURL");
			filePath = prop.getProperty("FilePath");
			policiesFile = prop.getProperty("policiesFilePath");

			if (testCaseNumber < 10) {
				testCase = "TC_0";
			} else {
				testCase = "TC_";
			}

			userName = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "UserName", filePath);
			password = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "Password", filePath);			
			//Action.ieSetUp();
			Action.launchTheMimicUrl(mimicLink);
			BlRegressionPage.ntid(Action.driverIE).sendKeys(userName);
			BlRegressionPage.passwrd(Action.driverIE).sendKeys(password);
			BlRegressionPage.selectEnv(Action.driverIE).selectByValue("regression");
			BlRegressionPage.logIn(Action.driverIE).click();

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}
	}

	@BeforeMethod

	public void getTheTestData() {

		try {
			if (testCaseNumber < 10) {
				testCase = "TC_0";
			} else {
				testCase = "TC_";
			}
			executionMode = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "GetThePolicies", filePath);
			//System.out.println("adkjcnbsajkcbajkdc "+ executionMode);
			request = Excel_Data.getExcelData(testCase + testCaseNumber, 0, "Request", filePath);
			totalRows = Excel_Data.getExcelRows(0, policiesFile);

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	@Test
	public static void mimicGeoBoxDetails() {

		ArrayList<String> policies = new ArrayList<String>();
		ArrayList<String> geoBoxDetails = new ArrayList<String>();
		List<String> controlNums = new ArrayList<String>();
	    List<Integer> matchedCntrl = new ArrayList<Integer>();
		ArrayList<ArrayList<String>> controlPlusGoBox = new ArrayList<ArrayList<String>>();
		

		try {

			switch (executionMode) {
			case "1":
				// *****Below code is to fetch the REquest Numbers which are
				// completed*
				int flag = 0;
				int copy = 2;
				boolean paginationPresent = true;
				BlRegressionPage.date(Action.driverIE);
				BlRegressionPage.status(Action.driverIE).click();
				do {
					int totalPolicies = BlRegressionPage.reqNumbers(Action.driverIE).size();
					for (int j = 0; j < totalPolicies;) {
						policies.add(BlRegressionPage.reqNumbers(Action.driverIE).get(j).getText());
						j = j + 4;
					}
					// pol = BlRegressionPage.pages(Action.driverIE).size();
					for (int i = 0; i < BlRegressionPage.pages(Action.driverIE).size(); i++) {
						if (BlRegressionPage.pages(Action.driverIE).get(i).getText().equals(">")) {

							JavascriptExecutor executor = (JavascriptExecutor) Action.driverIE;
							executor.executeScript("arguments[0].click();",
									BlRegressionPage.pages(Action.driverIE).get(i));
							BlRegressionPage.pages(Action.driverIE).get(i).click();
							System.out.println("Clicked");
							// Thread.sleep(3000);
							flag = 1;
							break;
						} else {

							flag = 2;
						}
					}
					if (flag == 2) {
						paginationPresent = false;
					}
				} while (paginationPresent == true);
				switch (copy) {

				case 1:

					Excel_Data.writeRequestToExcelData(1, 0, policies, filePath);
					policies.clear();
					break;

				case 2:
					List<String> alreadyCompleted = new ArrayList<String>();
					List<Integer> common = new ArrayList<Integer>();
					alreadyCompleted = Excel_Data.getTheExcelData(1, "Requests", filePath);
					// System.out.println(alreadyCompleted);
					for (int i = 0; i < policies.size(); i++) {
						for (int j = 0; j < alreadyCompleted.size(); j++) {
							if (policies.get(i).equals(alreadyCompleted.get(j))) {
								common.add(i);
								break;
							}
						}
					}
					for (int k = 0; k < common.size(); k++) {
						policies.remove(common.get(k) - k);
					}
					// System.out.println(policies);
					Excel_Data.writeRequestToExcelData(2, 0, policies, filePath);
					alreadyCompleted.clear();common.clear();					
					System.out.println("done");
				}
				break;

			case "2":				
				BlRegressionPage.requestSearch(Action.driverIE).sendKeys(request);
				BlRegressionPage.reqManagement(Action.driverIE).click();
				int elements = BlRegressionPage.getThePolicyNumber(Action.driverIE).size();
				// BlRegressionPage.loadedPoliciesOnly(Action.driverIE).size();
				int l = 0;
				for (int i = 0; i < elements; i++) {
					if (BlRegressionPage.loadedPoliciesOnly(Action.driverIE).get(l).getText().equals("Loaded")) {
						// System.out.println("hbscahbscahb" +
						// BlRegressionPage.loadedPoliciesOnly(Action.driverIE).get(l).getText());
						String policy = BlRegressionPage.getThePolicyNumber(Action.driverIE).get(i).getText();
						policies.add(policy);
					}
					l++;
				}
				//System.out.println(policies);
				controlNums = Excel_Data.getTheExcelData(0, "PolicyNumber",
						"C:\\Users\\mlatw\\Desktop\\MIMIC\\TestDataSetup.xlsx");
				//System.out.println(controlNums);
				for (int j = 0; j < controlNums.size(); j++) {
					for (int k = 0; k < policies.size(); k++) {
						if (policies.get(k).equals(controlNums.get(j).substring(6, 15))) {
							matchedCntrl.add(j + 1);							
						}
					}
				}
				geoBoxDetails = (ArrayList<String>) Excel_Data.getRowExcelData(matchedCntrl, 0, 0,
						"C:\\Users\\mlatw\\Desktop\\MIMIC\\TestDataSetup.xlsx");
				controlPlusGoBox.add(geoBoxDetails);
				controlPlusGoBox.add(policies);			
				System.out.println("Total Rows already present : " + totalRows);
				Excel_Data.writeToExcelData(totalRows, 0, 0, controlPlusGoBox, policiesFile);
				System.out.println("done");				
				controlPlusGoBox.clear();geoBoxDetails.clear();policies.clear();matchedCntrl.clear();controlNums.clear();
				Action.driverIE.navigate().back();
				testCaseNumber++;
				break;
				
			case "3" : 
				
				BlRegressionPage.policyManagement(Action.driverIE).click();
				BlRegressionPage.selectLoaded(Action.driverIE).click();
				Thread.sleep(30000);
				boolean pagination = true;
				int flags = 0;
				
				//do {
					for(int i = 1 ; i<BlRegressionPage.policyBox(Action.driverIE).size() ;i++){
						BlRegressionPage.policyBox(Action.driverIE).get(i).click();							
					}
					BlRegressionPage.actionMenu(Action.driverIE).click();
					Thread.sleep(1000);	
						BlRegressionPage.delectePolicies(Action.driverIE).click();
						Thread.sleep(2000);
						BlRegressionPage.deleteContinue(Action.driverIE).click();
						Thread.sleep(3000);	
					// pol = BlRegressionPage.pages(Action.driverIE).size();
					Thread.sleep(3000);
					
/*					for (int i = 0; i < BlRegressionPage.pages(Action.driverIE).size(); i++) {
						if (BlRegressionPage.pages(Action.driverIE).get(i).getText().equals(">")) {

							JavascriptExecutor executor = (JavascriptExecutor) Action.driverIE;
							executor.executeScript("arguments[0].click();",
									BlRegressionPage.pages(Action.driverIE).get(i));
							BlRegressionPage.pages(Action.driverIE).get(i).click();
							System.out.println("Clicked");
							((JavascriptExecutor) Action.driverIE).executeScript("window.scrollTo(0,0)");
							 Thread.sleep(3000);
							flags = 1;
							break;
						} else {

							flags = 2;
						}
					}
					if (flags == 2) {
						pagination = false;
					}
				} while (pagination == true);*/
  
/*				for(int i = 1 ; i<BlRegressionPage.policyBox(Action.driverIE).size() ; i++){
					BlRegressionPage.policyBox(Action.driverIE).get(i).click();					
				}
            
				BlRegressionPage.actionMenu(Action.driverIE).click();
				Thread.sleep(1000);
				BlRegressionPage.delectePolicies(Action.driverIE).click();
				BlRegressionPage.deleteContinue(Action.driverIE).click();*/
					//testCaseNumber++;	
								
			}} catch (Exception e) {
                 System.out.println(e);
                 mimicGeoBoxDetails();
		} 
	}

	@AfterSuite

	public static void closeTheSessions() {

		Action.tearDownIE();
		Action.tearDownChrome();
	}
}
