package MlqBL_Test;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.Keys;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Factory;
import org.testng.annotations.Test;
import Global_Function_Lib.Excel_Data;
import MlqBL_AppModule.Action;
import MlqBl_Page.BlRegressionPage;


public class OM_Mapper {

	static String releaseWeek;
	static String executionFlag = "";
	static String releaseDate = "";
	static String impersonateUrlsLink = "";
	static String wasServer = "";
	static String productFlag;
	static String state;
	static String impersonateUrlOfPresentWasServer = "";
	static int presentProductFlag = 0;
	static String filePath = null;
	static String downloadPath = null;
	static boolean isAlreadyRaised = false;
	static int testCaseNumber = 1;
	static int totalTestCases;
	static String testCaseSelect;
	static int totalRows;
	static String dcUrl="";

	@Factory
	public Object[] createClassInstance() {

		Object[] instance = new Object[1];
		for (int i = 0; i < 1; i++) {
			instance[i] = new Test_BLRegression();
		}
		return instance;
	}

	@BeforeSuite
	// **** below code use the .properties file for reading the data ********
	public void fileReader() {

		try {
			Properties prop = new Properties();
			String propFilename = "configs//Configuration.properties";
			InputStream inputStream = new FileInputStream(propFilename);

			if (inputStream != null) {
				prop.load(inputStream);
			}

			impersonateUrlsLink = prop.getProperty("ImpURL");
			filePath = prop.getProperty("FilePath");
			downloadPath = prop.getProperty("DownloadPath");
			dcUrl = prop.getProperty("DCUrl");
			totalTestCases = Excel_Data.getExcelRows(0, filePath);

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}
	}

	@BeforeMethod

	public void getTheTestData() {

		try {

			String date = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "ReleaseDate", filePath);
			releaseDate = date.substring(0, 2) + "/" + date.substring(2, 4) + "/" + date.substring(4, 8);
			wasServer = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "WasServer", filePath);
			productFlag = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "ProductFlag", filePath);
			releaseWeek = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "ReleaseWeek", filePath);
			testCaseSelect = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "TestCaseExecute", filePath);
			state = Excel_Data.getExcelData("TC_0" + testCaseNumber, 0, "State", filePath);

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	@Test()

	public static void getTheOMMapper() {
		Action action = new Action();
		List<String> controlNumbers = new ArrayList<String>();
		String pageNumber;
		switch (testCaseSelect) {
		case "TRUE":
			try {
				Action.chromeSetUp();
				impersonateUrlOfPresentWasServer = Action.launchTheImpersonateUrl(impersonateUrlsLink, wasServer);
				Action.tearDownChrome();
				//Action.ieSetUp();
/*				String dcWorkstationUrl = impersonateUrlOfPresentWasServer.substring(0, 28)
						+ "21180/NonProdUtilAutomationWEB/serviceLayerExecutor.do?method=load";*/
				String utilityUrl = impersonateUrlOfPresentWasServer.substring(0, 28) + "21180/NonProdUtilWEB/menu.do";
				Action.launchTheDCWorkstationURL(dcUrl);
				BlRegressionPage.blRegressionTabElement(Action.driverIE).click();
				BlRegressionPage.presentReleaseDate(Action.driverIE).selectByValue(releaseDate);
				Action.selectTheTransactionType(BlRegressionPage.transactionTypeElement(Action.driverIE));
				Action.selectTheRecordRange(BlRegressionPage.recordRangeElement(Action.driverIE));
				Action.selectTheReleaseWeek(BlRegressionPage.releaseWeekElement(Action.driverIE),
						Integer.parseInt(releaseWeek));
				BlRegressionPage.selectState(Action.driverIE, state);
				//Action.selectTheProductTypeExecution(Integer.parseInt(productFlag), Integer.parseInt(releaseWeek));
				Action.selectTheProductTypeExecution(presentProductFlag, releaseWeek);
				pageNumber = Action.getThePageNumbers();
				if (!pageNumber.contains("Previous")) {
						
					
					controlNumbers = action.getALLTheControlNumbers(Integer.parseInt(pageNumber));

				}
				BlRegressionPage.clearStateFilter(Action.driverIE).click();
				Action.tearDownIE();
				Action.ieSetUp();
				Action.launchTheDCWorkstationURL(utilityUrl);
				BlRegressionPage.acxmlTransformUtility(Action.driverIE).click();
				BlRegressionPage.reportType(Action.driverIE).click();
				for (int i = 0; i < controlNumbers.size(); i++) {
					BlRegressionPage.enterTheControlNumber(Action.driverIE).clear();
					BlRegressionPage.enterTheControlNumber(Action.driverIE)
							.sendKeys(controlNumbers.get(i).substring(0, 15));
					BlRegressionPage.submit(Action.driverIE).sendKeys(Keys.ENTER);

					Robot robot = new Robot();
					Thread.sleep(5000);
					Action.altNMethod(robot);
					Thread.sleep(2000);
					Action.tabMethod(robot);
					Thread.sleep(2000);

					Action.keyDownMethod(robot);
					Thread.sleep(2000);
					Action.keyDownMethod(robot);
					Thread.sleep(2000);

					Action.keyEnterMethod(robot);
					Thread.sleep(8000);

					Action.altDMethod(robot);
										
					Action.enterTheText(robot, downloadPath);
					Thread.sleep(3000);
					Action.keyEnterMethod(robot);

					Thread.sleep(3000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(5000);
					Action.enterTheText(robot, controlNumbers.get(i).substring(0, 15));

					Thread.sleep(6000);

					Action.keyEnterMethod(robot);
					Thread.sleep(2000);

					Action.altNMethod(robot);
					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);

					Thread.sleep(2000);
					Action.tabMethod(robot);
	
					Thread.sleep(2000);
					Action.keyEnterMethod(robot);

				}
				Action.tearDownIE();

			} catch (Exception e) {

			}
			break;

		case "FALSE":
			testCaseNumber++;
		}
	}
}
