package MlqBl_Page;

import MlqBL_AppModule.Action;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import Global_Function_Lib.Utility;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class BlRegressionPage {

	public static WebElement blRegressionTabElement(WebDriver driver) {		
		WebElement blRegressionTab = null;
		try {
			blRegressionTab = (new WebDriverWait(driver, 100))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("serviceExecutorSearchHd")));

		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "ErrorDCUrllaunch_");

		}
		return blRegressionTab;
	}

	public static List<WebElement> releaseDateElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;
		try {
			parent = driver.findElement(By.name("searchCriteria.selectedReleaseDate"));
			child = parent.findElements(By.tagName("option"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "releaseDateElement_");
		}

		return child;

	}

	public static List<WebElement> releaseWeekElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;

		try {
			parent = driver.findElement(By.id("drpReleaseWeek"));
			Thread.sleep(2000);
			child = parent.findElements(By.tagName("option"));

		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "releaseWeekElement_");
		}
		return child;
	}

	public static List<WebElement> releaseWeekExecutionElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;
		try {

			parent = driver.findElement(By.id("drpSbtReleaseWeek"));
			Thread.sleep(2000);
			child = parent.findElements(By.tagName("option"));

		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "releaseWeekExecutionElement_");
		}
		return child;
	}

	public static List<WebElement> transactionTypeElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;
		try {
			parent = driver.findElement(By.name("searchCriteria.selectedTransactionType"));
			Thread.sleep(2000);

			child = parent.findElements(By.tagName("option"));

		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "transactionTypeElement_");
		}

		return child;
	}

	public static List<WebElement> recordRangeElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;
		try {
			parent = driver.findElement(By.name("searchCriteria.pageNumber"));
			Thread.sleep(2000);
			child = parent.findElements(By.tagName("option"));

		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "recordRangeElement_");
		}
		return child;
	}

	public static List<WebElement> stateElement(WebDriver driver) {
		WebElement parent = null;
		List<WebElement> child = null;
		try {
			parent = driver.findElement(By.name("searchCriteria.selectedStates"));
			Thread.sleep(1000);
			child = parent.findElements(By.tagName("option"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "stateElement_");
		}

		return child;
	}

	public static List<WebElement> presenceOfAllPolicies(WebDriver driver) {
		List<WebElement> numberOfTransactionsOnPresentPage = null;
		try {
			numberOfTransactionsOnPresentPage = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("nobr")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presenceOfAllPolicies_");
		}
		return numberOfTransactionsOnPresentPage;

	}

	public static WebElement presentStatus(int policy, WebDriver driver) {
		WebElement statusCheck = null;
		try {
			statusCheck = (new WebDriverWait(driver, 20)).until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='getresult']/tbody/tr[" + policy + "]/td[9]/nobr/font")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presentStatus_");
		}
		return statusCheck;
	}

	public static WebElement refreshButton(WebDriver driver) {
		WebElement refresh = null;
		try {
			refresh = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='refreshstatus']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "refreshButton_");
		}
		return refresh;

	}

/*	public static Select regressionServer(WebDriver driver) {
		Select regressionServer = null;
		try {
			regressionServer = new Select(driver.findElement(By.id("drpRegressionServer")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "regressionServer_");
		}
		return regressionServer;
	}*/
	
	public static Select regressionServer(WebDriver driver) {
		Select regressionServer = null;
		try {
			regressionServer = new Select((new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("drpRegressionServer"))));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "regressionServer_");
		}
		return regressionServer;
	}
	
/*	public static Select states(WebDriver driver) {
		Select regressionServer = null;
		try {
			regressionServer = new Select(driver.findElement(By.name("searchCriteria.selectedStates")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchCriteria.selectedStates_");
		}
		return regressionServer;
	}*/
	public static Select states(WebDriver driver) {
		Select regressionServer = null;
		try {
			regressionServer = new Select((new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.name("searchCriteria.selectedStates"))));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchCriteria.selectedStates_");
		}
		return regressionServer;
	}

/*	public static Select presentReleaseDate(WebDriver driver) {
		Select releaseDate = null;
		try {
			releaseDate = new Select(driver.findElement(By.name("searchCriteria.selectedReleaseDate")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presentReleaseDate_");
		}
		return releaseDate;
	}*/
	
	public static Select presentReleaseDate(WebDriver driver) {
		Select releaseDate = null;
		try {
			releaseDate = new Select((new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.name("searchCriteria.selectedReleaseDate"))));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presentReleaseDate_");
		}
		return releaseDate;
	}

	public static WebElement searchElement(WebDriver driver) {
		WebElement serachButton = null;
		try {

			serachButton = (new WebDriverWait(driver, 30)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='serviceExecutorSearch']/form/fieldset[1]/div[2]/div[3]/input")));
		}

		catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchElement_");
		}
		return serachButton;
	}

	public static List<WebElement> productTypeElement(WebDriver driver) {
		WebElement elementProductType = null;
		List<WebElement> child = null;
		try {
			elementProductType = driver.findElement(By.id("drp_productType_BL"));
			child = elementProductType.findElements(By.tagName("option"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "productTypeElement_");
		}
		return child;
	}

	public static WebElement errorCodeElement(WebDriver driver) {
		WebElement elementErrorCode = null;
		try {
			elementErrorCode = driver.findElement(By.name("searchCriteria.errorCode"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "errorCodeElement_");
		}
		return elementErrorCode;

	}

	public static WebElement clearStatusFilter(WebDriver driver) {
		WebElement filterClearElement = null;
		try {
			filterClearElement = (new WebDriverWait(driver, 60)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='filterBox']/div[4]/div[5]/div[1]/div/span[2]")));
					//.presenceOfAllElementsLocatedBy(By.className("applied-filters")));
          
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "clearStatusFilter_");
		}
		return filterClearElement;

	}

	public static WebElement clearProductTypeFilter(WebDriver driver) {
		WebElement filterClearElement = null;
		try {
			List<WebElement> filterElement = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("applied-filters")));
			filterClearElement = filterElement.get(3);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "clearProductTypeFilter_");
		}
		return filterClearElement;

	}

	public static WebElement clearStateFilter(WebDriver driver) {
		WebElement filterClearElement = null;
		try {
			Thread.sleep(1000);
			filterClearElement = (new WebDriverWait(driver, 60)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='filterBox']/div[4]/div[1]/div[1]/div/span[2]")));
			((JavascriptExecutor) Action.driverIE).executeScript("arguments[0].scrollIntoView(true);",
					filterClearElement);
			Thread.sleep(2000);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "clearStateFilter_");
		}
		return filterClearElement;

	}

	public static WebElement statusBlank(WebDriver driver) {
		WebElement statusElement = null;
		try {
			statusElement = driver.findElement(By.xpath("//*[@id='filterBox']/div[4]/div[5]/div[2]/select/option[22]"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "statusBlank_");
		}
		return statusElement;

	}

	public static WebElement statusSystemErrorField(WebDriver driver) {
		WebElement statusElement = null;
		try {
			statusElement = driver.findElement(By.xpath("//*[@id='filterBox']/div[4]/div[5]/div[2]/select/option[16]"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "statusSystemErrorField_");
		}
		return statusElement;

	}
	
	public static List<WebElement> systemErrorFailed(WebDriver driver) {
		List <WebElement> statusElement = null;
		try {
			statusElement =(new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[name='searchCriteria.selectedStatus'] option")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "statusSystemErrorField_");
		}
		return statusElement;

	}

	public static WebElement statusComparison(WebDriver driver) {
		WebElement statusElement = null;
		try {
			statusElement = driver.findElement(By.xpath("//*[@id='filterBox']/div[4]/div[5]/div[2]/select/option[8]"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "statusComparison_");
		}
		return statusElement;

	}

	public static WebElement statusComparisonMismatch(WebDriver driver) {
		WebElement statusElement = null;
		try {
			statusElement = driver.findElement(By.xpath("//*[@id='filterBox']/div[4]/div[5]/div[2]/select/option[8]"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "statusComparisonMismatch_");
		}
		return statusElement;

	}


	public static WebElement search(WebDriver driver) {
		WebElement searchElement = null;
		try {
			searchElement = driver.findElement(By.xpath("//*[@id='getresult_filter']/label/input"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "search_");
		}
		return searchElement;

	}

	public static WebElement refresh(WebDriver driver) {
		WebElement refresh = null;
		try {
			refresh = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='refreshstatus']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "refresh_");
		}
		return refresh;

	}

	public static WebElement pageInitiationElement(WebDriver driver) {
		WebElement nextButton = null;
		try {
			nextButton = driver.findElement(By.id("getresult_next"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "pageInitiationElement_");
		}
		return nextButton;
	}

	public static List<WebElement> numberOfPagesPresentElement(WebDriver driver) {
		List<WebElement> child = null;
		try {
			child = (new WebDriverWait(driver, 30)).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By.className("paginate_button ")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "numberOfPagesPresentElement_");
		}
		return child;
	}

	public static WebElement nextButtonElement(WebDriver driver) {
		WebElement nextButton = null;
		try {
			nextButton = driver.findElement(By.id("getresult_next"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "nextButtonElement_");
		}
		return nextButton;

	}

	public static WebElement closedRequestISEnv(WebDriver driver) {
		WebElement elementClosedReq = null;
		try {
			elementClosedReq = (new WebDriverWait(driver, 10)).until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='closedServices']/div[1]/div[1]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "closedRequestISEnv_");
		}
		return elementClosedReq;

	}

	public static WebElement closedRequestISEnvAfterSearch(WebDriver driver) {
		WebElement elementClosedReq = null;
		try {
			elementClosedReq = (new WebDriverWait(driver, 5))
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='closedServices']/div/div[1]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "closedRequestISEnvAfterSearch_");
		}
		return elementClosedReq;
	}

	public static WebElement activeRequestHeader(WebDriver driver) {
		WebElement elementClosedReq = null;
		try {
			elementClosedReq = (new WebDriverWait(driver, 5))
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='openServices']/div/div[1]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "activeRequestHeader_");
		}
		return elementClosedReq;
	}

	public static WebElement activeRequest(WebDriver driver) {
		WebElement elementActiveReq = null;
		try {
			elementActiveReq = (new WebDriverWait(driver, 5)).until(ExpectedConditions
					.elementToBeClickable(By.xpath("//*[@id='tbl-true-0']/div/table/tbody/tr[2]/td[1]/a")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "activeRequest_");
		}
		return elementActiveReq;
	}

	public static List<WebElement> assignedTo(WebDriver driver) {
		List<WebElement> elementassignedTo = null;
		try {
			elementassignedTo = (new WebDriverWait(driver, 5)).until(
					ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='list2_body'] td")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "assignedTo_");
		}
		return elementassignedTo;
	}

	public static boolean checkAccordionVisibility(WebDriver driver) {

		boolean bool = false;
		WebElement elementClosedReq = null;
		try {
			elementClosedReq = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.className("accordion")));
			if (elementClosedReq.isEnabled()) {

				bool = true;
			}
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "checkAccordionVisibility_");
		}
		return bool;

	}

	public static WebElement selectReqNumAfterSearch(WebDriver driver) {
		WebElement elementReq = null;
		try {
			elementReq = (new WebDriverWait(driver, 30)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='tbl-false-0']/div/table/tbody/tr[2]/td[1]/a")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectReqNumAfterSearch_");
		}
		return elementReq;

	}

	public static WebElement requestOpenDate(WebDriver driver) {
		List<WebElement> elementOpenDate = null;
		try {
			elementOpenDate = (new WebDriverWait(driver, 20)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(
					By.cssSelector("[class='sn-widget-list sn-widget-list-table'] li span")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "requestOpenDate_");
		}
		return elementOpenDate.get(23);

	}

	public static WebElement requestCloseDate(WebDriver driver) {
		WebElement elementCloseDate = null;
		try {
			elementCloseDate = (new WebDriverWait(driver, 20)).until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='sn_form_inline_stream_entries']/ul/li[1]/div[3]/div/ul/li[1]/span[2]/span")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "requestCloseDate_");
		}
		return elementCloseDate;

	}

	public static WebElement serviceTask(WebDriver driver) {
		List<WebElement> elementServiceTask = null;
		try {
			elementServiceTask = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("select")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "serviceTask_");
		}
		return elementServiceTask.get(5);

	}

	public static List<WebElement> requestEntered(WebDriver driver) {
		List<WebElement> elementReqEntered = null;
		try {
			elementReqEntered = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("textarea")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "requestEntered_");
		}
		return elementReqEntered;
	}

	public static WebElement goBackToTheReqSearchPage(WebDriver driver) {
		List<WebElement> elementServiceTask = null;
		try {
			elementServiceTask = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("button")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "goBackToTheReqSearchPage_");
		}
		return elementServiceTask.get(0);

	}

	public static List<WebElement> closedRequestISEnvPageInitiation(WebDriver driver) {
		WebElement closedRequestISEnvPageInitiation = null;
		List<WebElement> child = null;
		try {
			closedRequestISEnvPageInitiation = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("reqCtnt-false-0")));
			child = closedRequestISEnvPageInitiation.findElements(By.tagName("li"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "closedRequestISEnvPageInitiation_");
		}
		return child;

	}

	public static List<WebElement> closedRequestISEnvPageRows(WebDriver driver) {
		WebElement closedRequestISEnvPageRows = null;
		List<WebElement> child = null;
		try {
			closedRequestISEnvPageRows = driver.findElement(By.id("reqCtnt-false-0"));
			child = closedRequestISEnvPageRows.findElements(By.tagName("tr"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "closedRequestISEnvPageRows_");
		}
		return child;

	}

	public static WebElement selectSystemNotification(WebDriver driver) {
		WebElement mandatory = null;
		try {
			mandatory = (new WebDriverWait(driver, 30))
					.until(ExpectedConditions.elementToBeClickable(By.id("MANDATORY")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectSystemNotification_");
		}
		return mandatory;

	}

	public static WebElement viewRecentlyClosed(WebDriver driver) {
		WebElement mandatory = null;
		try {
			mandatory = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='myservicesLink']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "viewRecentlyClosed_");
		}
		return mandatory;

	}

	public static WebElement searchByRequestNumber(WebDriver driver) {
		WebElement searchBy = null;
		List<WebElement> child = null;
		try {
			searchBy = driver.findElement(By.id("searchBySelect"));
			searchBy.click();
			child = searchBy.findElements(By.tagName("option"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchByRequestNumber_");
		}
		return child.get(1);

	}

	public static WebElement requestNumberTextBox(WebDriver driver) {
		WebElement requestNumberText = null;
		try {
			requestNumberText = (new WebDriverWait(driver, 30))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='searchByText']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "requestNumberTextBox_");
		}
		return requestNumberText;

	}

	public static WebElement requestNumberSearch(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='searchButton']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "requestNumberSearch_");
		}
		return search;

	}

	public static WebElement viewAllItems(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.elementToBeClickable(By.className("sc_bottom_link")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "isEnv_");
		}
		return search;

	}

	public static WebElement isEnv(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 20)).until(ExpectedConditions.elementToBeClickable(By.xpath(
					"/html/body/div[2]/table/tbody/tr/td[1]/table/tbody[7]/tr/td/div/table/tbody/tr/td[2]/table/tbody/tr/td/a/div")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "isEnv_");
		}
		return search;

	}

	public static WebElement innerISEnv(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='item_link_a3941b3bdb7972c0649bd604ce9619e2']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "innerISEnv_");
		}
		return search;

	}

	public static void dcioPT(WebDriver driver) {
		Select search = null;
		try {
			search = new Select(driver.findElement(By.id("IO:2048ed16871e4500d0a07bfd19434dbc")));
			search.selectByValue("PT - Product Technology");
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "dcioPT_");
		}

	}
	
	public static void selectState(WebDriver driver , String state) {
		Select search = null;
		try {
			search = new Select(driver.findElement(By.name("searchCriteria.selectedStates")));
			search.selectByValue(state);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, state);
		}

	}

	public static void areaOfBusinessPT(WebDriver driver) {
		Select search = null;
		try {

			search = new Select(driver.findElement(By.id("IO:eca92556871e4500d0a07bfd19434d2f")));
			search.selectByValue("Product Technology");
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "areaOfBusinessPT_");
		}

	}

	public static void platformLinux(WebDriver driver) {
		Select search = null;
		try {
			search = new Select(driver.findElement(By.id("IO:035168e1db8a7ac04020d024ce9619f4")));
			search.selectByValue("Linux");
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "platformLinux_");
		}

	}

	public static WebElement application(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='sys_display.IO:cbb2a0e1db8a7ac04020d024ce961959']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "application_");
		}
		return search;

	}
	
	public static WebElement acxmlTransformUtility(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.cssSelector("[title='OM ACXML TRANSFORM Utility']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "acxmlUtility");
		}
		return search;
	}
	
	public static WebElement reportType(WebDriver driver) {
		List<WebElement> search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By.cssSelector("[name='reportType'] option")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "report_type");
		}
		return search.get(1);
	}
	
	public static WebElement enterTheControlNumber(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.cssSelector("[name='controlPolNum']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "Search box");
		}
		return search;
	}
	
	public static WebElement submit(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 20)).until(ExpectedConditions
					.presenceOfElementLocated(By.cssSelector("[type='submit']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "Submit");
		}
		return search;
	}

	public static WebElement searchIcon(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='lookup.IO:cbb2a0e1db8a7ac04020d024ce961959']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchIcon_");
		}
		return search;

	}

	public static WebElement selectAlliance(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='row_cmdb_ci_016ff2f885d2b800ce51781e11dfeed5']/td[3]/a")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectAlliance_");
		}
		return search;

	}

	public static WebElement selectServiceTask(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='IO:5623e0a9db8a7ac04020d024ce961962']/option[11]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectServiceTask_");
		}
		return search;

	}

	public static WebElement calenderIcon(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(
					By.xpath("//*[@id='ni.IO:ad88e4e1dbca7ac04020d024ce96196c.ui_policy_sensitive']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "calenderIcon_");
		}
		return search;

	}

	public static WebElement selectPresentDate(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(
					By.cssSelector("[class='calText calCurrentDate'] [aria-selected='true']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectPresentDate_");
		}
		return search;

	}

	public static WebElement reportedReason(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='IO:024e0dc7dbd6b6404020d024ce96197d']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "reportedReason_");
		}
		return search;

	}

	public static WebElement additionalReason(WebDriver driver) {
		WebElement search = null;
		try {
			search = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='IO:0b504de2dbc2f2004020d024ce961928']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "additionalReason_");
		}
		return search;

	}

	public static WebElement orderRequest(WebDriver driver) {
		WebElement order = null;
		try {
			order = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='order_now']/img")));
			((JavascriptExecutor) Action.driverChrome).executeScript("arguments[0].scrollIntoView(true);", order);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "orderRequest_");
		}
		return order;

	}

	public static WebElement lastSysErrorField(int policy, WebDriver driver) {

		int policyNumber = policy;
		WebElement systemErrorField = null;
		try {
			systemErrorField = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(
					By.xpath("//*[@id='getresult']/tbody/tr[" + ++policyNumber + "]/td[9]/nobr/font/img")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "lastSysErrorField_");
		}
		return systemErrorField;

	}

	public static WebElement checkForTheErrorDescription(WebDriver driver) {
		WebElement systemErrorDescription = null;
		try {
			systemErrorDescription = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='errContent']/fieldset/div/table/tbody/tr/td[2]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "checkForTheErrorDescription_");
		}
		return systemErrorDescription;

	}

	public static WebElement checkForTheErrorCode(WebDriver driver) {
		WebElement systemErrorDescription = null;
		try {
			systemErrorDescription = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='errContent']/fieldset/div/table/tbody/tr/td[1]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "checkForTheErrorCode_");
		}
		return systemErrorDescription;

	}

	public static WebElement closeButton(WebDriver driver) {
		WebElement close = null;
		try {
			close = (new WebDriverWait(driver, 15))
					.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[title='Close']")));
			// (By.xpath("/html/body/div[3]/div[1]/button")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "closeButton_");
		}
		return close;

	}

	public static WebElement earResult(WebDriver driver) {
		WebElement message = null;
		try {
			message = driver.findElement(By.tagName("body"));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "earResult_");
		}
		return message;
	}

	public static List<WebElement> wasServerList(WebDriver driver) {
		List<WebElement> servers = null;
		try {
			servers = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tbody tr")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "wasServerList_");
		}
		return servers;

	}

	public static WebElement wasServerName(WebDriver driver) {
		WebElement serverName = null;
		try {
			serverName = (new WebDriverWait(driver, 10)).until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='content']/tbody/tr/td[4]/b/a")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "wasServerName_");
		}
		return serverName;

	}

	public static WebElement impersonateURLOfPresentWasServer(WebDriver driver) {
		WebElement serverName = null;
		try {
			serverName = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='content']/tbody/tr/td[5]")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "impersonateURLOfPresentWasServer_");
		}
		return serverName;

	}

	public static WebElement searchServerInImpersonateURL(WebDriver driver) {
		WebElement serverName = null;
		try {
			serverName = (new WebDriverWait(driver, 10)).until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='content_filter']/label/input")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "searchServerInImpersonateURL_");
		}
		return serverName;

	}

	public static List<WebElement> stateList(WebDriver driver) {
		List<WebElement> states = null;
		try {
			states = (new WebDriverWait(driver, 10)).until(ExpectedConditions
					.presenceOfAllElementsLocatedBy(By.cssSelector("[name='searchCriteria.selectedStates'] option")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "stateList_");
		}
		return states;

	}

	public static WebElement returnBackToCatalog(WebDriver driver) {
		WebElement returnBack = null;
		try {
			returnBack = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='returnHome']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "returnBackToCatalog_");
		}

		return returnBack;

	}

	public static List<WebElement> selectStateHeaderTile(WebDriver driver) {
		List<WebElement> states = null;
		try {
			states = (new WebDriverWait(driver, 10)).until(
					ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='tbl-header'] th")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectStateHeaderTile_");
		}
		return states;

	}

	public static List<WebElement> selectStateNameAtTop(WebDriver driver) {
		List<WebElement> states = null;
		try {
			states = (new WebDriverWait(driver, 10)).until(
					ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='text-left sorting_1']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "selectStateNameAtTop_");
		}
		return states;

	}

	public static WebElement clearedProductTypeFilter(WebDriver driver) {
		WebElement filterClearElement = null;
		try {
			List<WebElement> filterElement = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("filter-count")));
			filterClearElement = filterElement.get(3);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "clearProductTypeFilter_");
		}
		return filterClearElement;

	}

	public static WebElement clearedStateFilter(WebDriver driver) {
		WebElement filterClearElement = null;
		try {
			List<WebElement> filterElement = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("filter-count")));
			filterClearElement = filterElement.get(0);
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "clearProductTypeFilter_");
		}
		return filterClearElement;

	}
	
	public static WebElement ntid(WebDriver driver) {
		WebElement id = null;
		try {
			 id = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("username")));
				

		} catch (Exception e) {
		System.out.println(e);
		}
		return id;
	}
	
	public static WebElement passwrd(WebDriver driver) {
		WebElement pass = null;
		try {
			 pass = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("password")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return pass;
	}
	
	public static Select selectEnv(WebDriver driver) {
		Select env = null;
		try {
			env = new Select(driver.findElement(By.id("environment")));
		} catch (Exception e) {
			System.out.println(e);
		}
		return env;
	}
	
	public static WebElement logIn(WebDriver driver) {
		WebElement log = null;
		try {
			log = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("btnLogin")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return log;
	}
	
	public static WebElement requestSearch(WebDriver driver) {
		WebElement req = null;
		try {
			req = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("searchRequest")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return req;
	}
	
	public static WebElement reqManagement(WebDriver driver) {
		WebElement req = null;
		try {
			req = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfElementLocated(By.className("requestor")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return req;
	}
	
	public static List<WebElement> getThePolicyNumber(WebDriver driver) {	
		List<WebElement> policy = null;
		try {
			 policy = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tr td div")));			
		} catch (Exception e) {
			System.out.println(e);
		}
		return policy;
	}
	
	public static List<WebElement> loadedPoliciesOnly(WebDriver driver) {	
		List<WebElement> loaded = null;
		try {
			 loaded = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tbody tr span")));			
		} catch (Exception e) {
			System.out.println(e);
		}
		return loaded;
	}
	
	public static List<WebElement> next(WebDriver driver) {
		List<WebElement> nextButton = null;
		try {
			nextButton = (new WebDriverWait(driver, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='page-item'] a")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return nextButton;
	}
	
	public static WebElement status(WebDriver driver) {

		List<WebElement> stat = null;
		try {
			stat = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='col-lg-2'] option")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return stat.get(2);
	}
	
	public static List<WebElement> pages(WebDriver driver) {
		List<WebElement> numOfPolicies = null;
		try {
			numOfPolicies = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='pagination'] li")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return numOfPolicies;
	}
	
	public static List<WebElement> reqNumbers(WebDriver driver) {
		List<WebElement> numOfPolicies = null;
		try {
			numOfPolicies = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tr td div")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return numOfPolicies;
	}

	public static void date(WebDriver driver) throws Exception {

		WebElement stat = (new WebDriverWait(driver, 20))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='filterStartDate']")));
		stat.click();

		List<WebElement> months = (new WebDriverWait(driver, 20))
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
						By.cssSelector("[class='DayPicker-Month'] [class='DayPicker-Caption']")));
		
		Thread.sleep(5000);
		List<WebElement> nav = (new WebDriverWait(driver, 20)).until(
				ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='DayPicker-NavBar'] span")));
		//System.out.println(nav.size());
		while (!months.get(1).getText().equals("January 2019")) {

			nav.get(1).click();

		}		
		List<WebElement> monthTag = (new WebDriverWait(driver, 20))
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("DayPicker-Month")));		
		List<WebElement> weeks   =  monthTag.get(1).findElements(By.className("DayPicker-Week"));
		List<WebElement> days = weeks.get(3).findElements(By.tagName("div"));		
		//System.out.println("adnclkcnkacnkackcn " + days.size());
		for (int j = 0; j < days.size(); j++) {
			//System.out.println(days.get(j).getText());
			if (days.get(j).getText().equals("21")) {
				days.get(j).click();
				break;
			}
		}		
	}
	
	public static WebElement selectAll(WebDriver driver) {
		WebElement selectall = null;
		try {
			selectall = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("selectall")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return selectall;
	}
	
	public static WebElement confirmAndSubmit(WebDriver driver) {
		WebElement confirm = null;
		try {
			confirm = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("btn_showConfirmBox")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return confirm;
	}
	
	public static WebElement confirmSubmit(WebDriver driver) {
		WebElement confirm = null;
		try {
			confirm = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/div[11]/div/button[1]/span")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return confirm;
	}

	public static List<WebElement> controlNumbers(WebDriver driver) {
		List<WebElement> numOfPolicies = null;
		try {
			numOfPolicies = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("tbody tr [class='text-left td-testcaseId']")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return numOfPolicies;
	}
	
	public static List<WebElement> statusCheck(WebDriver driver) {
		List<WebElement> statusCheck = null;
		try {
			statusCheck = (new WebDriverWait(driver, 20)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(
					By.tagName("font")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presentStatus_");
		}
		return statusCheck;
	}
	
	public static List<WebElement> stateNames(WebDriver driver) {
		List<WebElement> stateName = null;
		try {
			stateName = (new WebDriverWait(driver, 20)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(
					By.cssSelector("[class='text-left sorting_1']")));
		} catch (Exception e) {
			Utility.captureScreenshot(Action.driverIE, "presentStatus_");
		}
		for(int i = 0; i<stateName.size();i++){
			
		}
		return stateName;
	}

	public static WebElement controlNumberWithError(WebDriver driver, int index) {
		WebElement controlNumber = null;
		try {
			controlNumber = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='getresult']/tbody/tr[" + index + "]/td[3]")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return controlNumber;
	}
	
	public static WebElement nextButton(WebDriver driver) {
		WebElement next = null;
		try {
			next = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='getresult_wrapper']/div[4]/a[3]")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return next;
	}
	
	public static WebElement policyManagement(WebDriver driver) {
		WebElement next = null;
		try {
			next = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[href='/policymanagement']")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return next;
	}
	
	 
	public static List<WebElement> policyBox(WebDriver driver) {
		List<WebElement> checkBox = null;
		try {
			checkBox = (new WebDriverWait(driver, 200))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[type='checkbox']")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return checkBox;
	}
	
	public static WebElement actionMenu(WebDriver driver) {
		List<WebElement> action = null;
		try {
			action = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='dropdown'] button")));
				
			//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", action.get(0));
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");	 
			 Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println(e);
		}
		return action.get(0);
	}
	
	public static WebElement delectePolicies(WebDriver driver) {
		WebElement del = null;
		try {
			del = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("deletePolicies")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return del;
	}
	
	public static WebElement deleteContinue(WebDriver driver) {
		WebElement del = null;
		try {
			del = (new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("deletePoliciesSubmitBtn")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return del;
	}
	
	public static WebElement selectLoaded(WebDriver driver) {
		List<WebElement> load = null;
		try {
			load = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[id='cdbStatus'] option")));
		} catch (Exception e) {
			
		}
		return load.get(4);
	}
	
	public static WebElement admin(WebDriver driver) {
		WebElement admin = null;
		try {
			admin = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("adminHd")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return admin;
	}
	
	public static WebElement configurationProperties(WebDriver driver) {
		List<WebElement> config = null;
		try {
			config = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='left-tab-wapper'] div input")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return config.get(14);
	}
	
	public static List<WebElement> compareMode(WebDriver driver) {
		List<WebElement> checkBox = null;
		try {
			checkBox = (new WebDriverWait(driver, 60))
					//.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='runSummaryGrid'] tbody tr td")));
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("input[value='Edit']")));					

		} catch (Exception e) {
			System.out.println(e);
		}
		return checkBox;
	}
	
	public static WebElement modeValue(WebDriver driver) {
		WebElement mode = null;
		try {
			mode = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("propertyValue")));				
		} catch (Exception e) {
			System.out.println(e);
		}
		return  mode;
	}
	
	public static WebElement saveProperty(WebDriver driver) {
		WebElement mode = null;
		try {
			mode = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("[class='lightbutton80'][value='Save Property']")));				
		} catch (Exception e) {
			System.out.println(e);
		}
		return  mode;
	}
	
	public static List<WebElement> editButton(WebDriver driver) {
		List<WebElement> checkBox = null;
		try {
			checkBox = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("[class='runSummaryGrid'] tbody tr")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return checkBox;
	}
	public static Select releaseWeek(WebDriver driver) {
		Select releaseWeek = null;
		try {
			releaseWeek = new Select(driver.findElement(By.name("searchCriteria.selectedReleaseWeek")));
		} catch (Exception e) {
			System.out.println(e);
		}
		return releaseWeek;
	}
	
/*	public static Select regressionReleaseWeek(WebDriver driver) {
		Select releaseWeek = null;
		try {
			releaseWeek = new Select(driver.findElement(By.name("selectedReleaseWeek")));
		} catch (Exception e) {
			System.out.println(e);
		}
		return releaseWeek;
	}*/
	public static Select regressionReleaseWeek(WebDriver driver) {
		Select releaseWeek = null;
		try {
			releaseWeek = new Select((new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.name("selectedReleaseWeek"))));
		} catch (Exception e) {
			System.out.println(e);
		}
		return releaseWeek;
	}
	
	public static Select transactionType(WebDriver driver) {
		Select producttyp = null;
		try {
			producttyp = new Select((new WebDriverWait(driver, 20))
					.until(ExpectedConditions.presenceOfElementLocated(By.name("searchCriteria.selectedTransactionType"))));
		} catch (Exception e) {
			System.out.println(e);
		}
		return producttyp;
	}
	
	public static WebElement testCaseCount(WebDriver driver) {
		
		WebElement batch = null;
		try {
			batch = (new WebDriverWait(driver, 60))
					.until(ExpectedConditions.presenceOfElementLocated(By.id("spn_batchCount")));
				

		} catch (Exception e) {
			System.out.println(e);
		}
		return batch;		
	}
}


