package MlqBL_AppModule;

import MlqBl_Page.BlRegressionPage;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.*;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.String;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import Global_Function_Lib.Utility;

public class Action  {
	
	public static RemoteWebDriver driverIE;
	public static RemoteWebDriver driverChrome;
/*	@Parameters({"driver"})
	@Test
	public static void assignTheDrivers(RemoteWebDriver driver){
		
		 driverIE  = driver;
	}	*/
	static List<String> errors = new ArrayList<String>();
	static String chromeDriverPath = "";
	static String ieDriverPath = "";
	static String catalogUrl = "";
	//public static WebDriver driverChrome;
	//public static WebDriver driverIE;
	
	//public static RemoteWebDriver driverIE;
	static List<String> controlNumbers = new ArrayList<String>();
	
/*	@BeforeSuite
	public void getTheDriverPath() throws Exception {

		Properties prop = new Properties();
		String propFilename = "configs//Configuration.properties";
		InputStream inputStream = new FileInputStream(propFilename);
		prop.load(inputStream);
		chromeDriverPath = prop.getProperty("ChromeDriverPath");
		ieDriverPath = prop.getProperty("IEDriverPath");
		catalogUrl = prop.getProperty("CatalogUrl");
		
	}*/

	public static void ieSetUp()  {
	//public static void ieSetUp(RemoteWebDriver driver)  {
/*		System.setProperty("webdriver.ie.driver", ieDriverPath);
		driverIE = new InternetExplorerDriver();
		driverIE.manage().window().maximize();*/
		DesiredCapabilities dc =  DesiredCapabilities.internetExplorer();

		try {
			driverIE = new RemoteWebDriver(new URL("http://397AD-5C210094:4444/wd/hub"), dc);
		//	driver = new RemoteWebDriver(new URL("http://397AD-5C210094:4444/wd/hub"), dc);

		} catch (MalformedURLException e) {
			
			e.printStackTrace();
		} 

	}

	public static void chromeSetUp()  {
/*		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);		
		options.addArguments("start-maximized");		
		options.addArguments("start-maximized");
		driverChrome = new ChromeDriver(options);*/
		DesiredCapabilities dc1 = DesiredCapabilities.chrome(); 
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);	
		options.addArguments("start-maximized");		
		dc1.setCapability(ChromeOptions.CAPABILITY, options);
		try {
			driverChrome = new 	RemoteWebDriver (new URL ("http://397AD-5C210094:4444/wd/hub"), dc1);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void enterTheText(Robot robot,String text) {
		StringSelection stringSelection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
	}

	public static void launchTheDCWorkstationURL(String url) throws InterruptedException  {

		try {	
			
			//String url =  "https://lxv3102.allstate.com:21143/NonProdUtilAutomationWEB/serviceLayerExecutor.do?method=load";
			driverIE.get(url);
			//driver.get(url);
			Thread.sleep(7000);
			driverIE.switchTo().alert().accept();
			//driver.switchTo().alert().accept();
		} catch (Exception e) {
			Thread.sleep(20000);
			System.out.println(e);
			Action.launchTheDCWorkstationURL(url);						
		}
	}
	
	public static void launchTheMimicUrl(String mimiclink) throws Exception {

		try {	
		
			driverIE.get(mimiclink);

		 } catch (Exception e) {
			 
			 System.out.println(e);

		}
	}
	
	

	public boolean launchTheEAR(String url, int earFlag) {

		boolean earUp = false;
		driverChrome.get(url);
		driverChrome.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement message = BlRegressionPage.earResult(driverChrome);
		if (message.getText().contains("Received ping")) {

			System.out.println(message.getText());
			earUp = true;
		} else {
			switch (earFlag) {
			case 0:
				System.out.println("EAR is not up please raise a request to make it up");
				break;
			case 1:
				System.out.println("Request for EAR has been raised and waiting for its Service.");

			}
		}
		return earUp;
	}

	public static String checkForTheErrorMessage(String url) {
		String errorMessage = "";
		driverChrome.get(url);
		driverChrome.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement message = BlRegressionPage.earResult(driverChrome);
		errorMessage = message.getText();
		return errorMessage;
	}

	public static String launchTheImpersonateUrl(String url, String presentWasServer) {

		String impersonateUrl = "";
		driverChrome.get(url);
		BlRegressionPage.searchServerInImpersonateURL(driverChrome).sendKeys(presentWasServer);

		if (BlRegressionPage.wasServerName(driverChrome).getText().contains(presentWasServer)) {

			impersonateUrl = BlRegressionPage.impersonateURLOfPresentWasServer(driverChrome).getText();
		}
		return impersonateUrl;
	}

	public static void selectTheReleaseDate(List<WebElement> elementProperty) {

		elementProperty.get(0).click();

	}

	public static void selectTheReleaseWeek(List<WebElement> elementProperty, int presentRelease) {

		elementProperty.get(presentRelease).click();
	}

	public static void selectTheTransactionType(List<WebElement> elementProperty) {

		elementProperty.get(1).click();
	}

	public static void selectTheRecordRange(List<WebElement> elementProperty) {

		elementProperty.get(1).click();
	}

	public static void selectTheState(int state, List<WebElement> elementProperty) {

		elementProperty.get(state).click();

	}

	public static void selectAutoProductType(List<WebElement> elementProperty) {

		elementProperty.get(1).click();
	}

	public static void selectPUPProductType(List<WebElement> elementProperty) {

		elementProperty.get(8).click();
	}
	
	public static void selectBoatProductType(List<WebElement> elementProperty) {

		elementProperty.get(2).click();
	}
	
	public static void selectMFHProductType(List<WebElement> elementProperty) {

		elementProperty.get(7).click();
	}

	public static void selectBlankStatus(WebElement elementProperty) {

		elementProperty.click();
	}

	public static void selectSystemErrorField(WebElement elementProperty) {

		elementProperty.click();
	}

	public static void selectPropertyProductType(List<WebElement> elementProperty) {

		Actions builder = new Actions(driverIE);
		builder.keyDown(Keys.CONTROL);
		elementProperty.get(3).click();
		elementProperty.get(4).click();
		elementProperty.get(5).click();
		builder.keyUp(Keys.CONTROL).build().perform();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}
	
	public static void selectLPPProductType(List<WebElement> elementProperty) {
	//productTypeElement
		elementProperty.get(6).click();	
	}

	public static void selectMotorProductType(List<WebElement> elementProperty) {

		Actions builder = new Actions(driverIE);
		builder.keyDown(Keys.CONTROL);
		elementProperty.get(9).click();
		elementProperty.get(10).click();
		elementProperty.get(11).click();
		builder.keyUp(Keys.CONTROL).build().perform();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}
	public static void selectSystemErrorFailed(List<WebElement> elementProperty) {

		Actions builder = new Actions(driverIE);
		builder.keyDown(Keys.CONTROL);
		elementProperty.get(9).click();
		elementProperty.get(14).click();
		elementProperty.get(15).click();
		elementProperty.get(16).click();
		elementProperty.get(17).click();
		elementProperty.get(18).click();
		elementProperty.get(23).click();
		elementProperty.get(24).click();
		builder.keyUp(Keys.CONTROL).build().perform();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	public static void searchByTheErrorCode(WebElement elementProperty, String errorCode) {

		elementProperty.sendKeys(errorCode);
	}

	public static void clearTheErrorCode(WebElement elementProperty) {

		elementProperty.clear();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	public static void clearTheStatusFilter(WebElement elementProperty) {

		elementProperty.click();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	public static void clearTheStateFilter(WebElement elementProperty) {
		((JavascriptExecutor) driverIE).executeScript("arguments[0].scrollIntoView(true);", elementProperty);
		elementProperty.click();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	public static void selectTheReleaseWeekForExecution(List<WebElement> elementProperty, int presentRelease) {

		elementProperty.get(presentRelease).click();
	}

	public static void selectRegressionserver(WebElement elementProperty) {

		elementProperty.click();
	}

	public static void clearTheSearchBox(WebElement elementProperty) {

		elementProperty.sendKeys(Keys.CONTROL, "a");
 		elementProperty.sendKeys(Keys.DELETE); 		

	}

	public static void selectSearchButton(WebElement elementProperty) {

		elementProperty.click();
		driverIE.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

	}

	public static int getThePresentPageTransaction(List<WebElement> elementProperty) {

		int transactionOnPage = elementProperty.size();
		return transactionOnPage;
	}

	public static String[] getThePages(List<WebElement> elementProperty) {

		String[] pages = new String[elementProperty.size()];
		for (int i = 0; i < elementProperty.size(); i++) {
			pages[i] = elementProperty.get(i).getText();
		}

		return pages;
	}

	public static int getTheTotalPagesToBeClicked(List<WebElement> elementProperty) {

		int totalPages = elementProperty.size();
		return totalPages;
	}

	public static boolean getTheEnabledNextButton(WebElement elementProperty) {

		boolean enabled;
		enabled = elementProperty.isEnabled();
		return enabled;

	}

	public String statusTextOfFailedTransaction(WebElement elementProperty) {

		String elementText = elementProperty.getText();
		return elementText;
	}

	public boolean statusCheckOfTheTransaction(int policyNumber) {// ,List<WebElement>
																	// elementProperty){

		String status;
		boolean bool = false;
		List<WebElement> statusCheck = (new WebDriverWait(driverIE, 10))
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("font")));
		if (policyNumber >= 6) {
			int scroller = policyNumber;
			((JavascriptExecutor) driverIE).executeScript("arguments[0].scrollIntoView(true);",
					statusCheck.get(scroller - 4));
		}
		status = statusCheck.get(policyNumber).getText();

		if (status.length() == 0) {
			bool = true;
		}
		return bool;
	}

	public void selectTheCheckBox(int transactionNumber) {

		List<WebElement> checkBox = driverIE.findElements(By.className("searchresult"));
		checkBox.get(transactionNumber).click();

	}

	public void submitThePolicies(int transactionNumber) {

		List<WebElement> checkBox = driverIE.findElements(By.className("searchresult"));
		checkBox.get(transactionNumber).click();
		driverIE.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driverIE.findElement(By.id("btn_showConfirmBox")).click();
		driverIE.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driverIE.findElement(By.xpath("/html/body/div[2]/div[11]/div/button[1]/span")).click();
		driverIE.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

	}

	public void selectTheTransactionAndSubmit() throws Exception {
		BlRegressionPage.selectAll(driverIE).click();
		Thread.sleep(1000);
		BlRegressionPage.clearStatusFilter(Action.driverIE).click();
		BlRegressionPage.confirmAndSubmit(driverIE).click();
		BlRegressionPage.confirmSubmit(driverIE).click();
		Thread.sleep(1000);
		//BlRegressionPage.clearStatusFilter(Action.driverIE).click();	
/*		
		((JavascriptExecutor) driverIE).executeScript("window.focus();");	
		driverIE.executeScript("javascript: setTimeout(\"history.go(0)");
		Thread.sleep(1000);
		Action.driverIE.switchTo().alert().accept();*/
/*		Thread.sleep(1000);
		driverIE.findElement(By.cssSelector("[class='ui-widget-overlay ui-front']")).sendKeys(Keys.F5);*/
		//ui-widget-overlay ui-front
		//Robot robot = new Robot();
		//Action.refreshMethod(robot);
		//Thread.sleep(1000);

		/*Actions actions = new Actions(Action.driverIE);
		Thread.sleep(1000);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).perform();*/
/*		Thread.sleep(3000); 
        Action.driverIE.switchTo().alert().accept();*/
/*		BlRegressionPage.searchElement(driverIE).click();

		String pageNumber = Action.getThePageNumbers();
		if (!pageNumber.contains("Previous")) {

			int pageNum = Integer.parseInt(pageNumber);
			for (int i = 1; i <= pageNum; i++) {
				int cntrls = BlRegressionPage.statusCheck(driverIE).size();
	
					for(int j =0 ; j<cntrls ; j++){
						if (j >= 6) {

							int scroller = j;
							((JavascriptExecutor) driverIE).executeScript("arguments[0].scrollIntoView(true);",
									BlRegressionPage.presentStatus((scroller - 5), driverIE));
						}					 
						 String status =  BlRegressionPage.statusCheck(driverIE).get(j).getText();

					  while( status.equals("New") || status.equals("Baseline Completed") || status.equals("Field Execution")){
						  BlRegressionPage.refreshButton(driverIE).click();
						  status =  BlRegressionPage.statusCheck(driverIE).get(j).getText();
					      Thread.sleep(3000);                      
					}

				}*/
					
	/*				if (pageNum > 1) {

						BlRegressionPage.nextButton(driverIE).click();
					}
			}
		}*/
	}

	public List<String> getALLTheControlNumbers(int totalPages) {

		BlRegressionPage.search(driverIE).clear();
		WebElement count = driverIE.findElement(By.xpath("//*[@id='test']"));
		String countDisplay = count.getText();
		String[] countSplit = countDisplay.split("\\s");
		int j = 1;
		int i = 0;
		String[] controlNumbers = new String[Integer.parseInt(countSplit[countSplit.length - 1])];
		System.out.println("control numbers array size is : " + controlNumbers.length);
		do {
			List<WebElement> statusCheckInDo = (new WebDriverWait(driverIE, 10))
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.tagName("font")));

			for (int k = 1; k <= statusCheckInDo.size(); k++) {
				int scroller = k;
				((JavascriptExecutor) driverIE).executeScript("arguments[0].scrollIntoView(true);",
						statusCheckInDo.get(--scroller));
				WebElement policyControlNumber = Action.driverIE
						.findElement(By.xpath("//*[@id='getresult']/tbody/tr[" + k + "]/td[3]"));
				controlNumbers[i++] = policyControlNumber.getText();
			}
			j++;
			if (totalPages > 1 && j <= totalPages) {

				// System.out.println("value of j : "+ j);
				WebElement nextButton = driverIE.findElement(By.xpath("//*[@id='getresult_wrapper']/div[4]/a[3]"));

				nextButton.click();
				// j++;
			}
		} while (j <= totalPages);
		return Arrays.asList(controlNumbers);
	}

	public void searchAndSubmitThePolicy(String policyNumber) throws InterruptedException {

		BlRegressionPage.search(driverIE).clear();
		BlRegressionPage.search(driverIE).sendKeys(policyNumber);
		Thread.sleep(1000);
		// int submitCount =
		// Integer.parseInt(driverIE.findElement(By.id("spn_testcaseCount")).getText());
		BlRegressionPage.refreshButton(Action.driverIE).click();
		/*
		 * do{ BlRegressionPage.refreshButton(Action.driverIE).click();
		 * Thread.sleep(2000); String nowSubmitCount =
		 * driverIE.findElement(By.id("spn_testcaseCount")).getText();
		 * if(Integer.parseInt(nowSubmitCount) == 0){ Thread.sleep(1000); String
		 * latestSubmitCount =
		 * driverIE.findElement(By.id("spn_testcaseCount")).getText();
		 * if(Integer.parseInt(latestSubmitCount) == 0){ submitCount = 0; } }
		 * 
		 * }while(submitCount > 0);
		 */
		WebElement statusCheck = (new WebDriverWait(driverIE, 10))
				.until(ExpectedConditions.presenceOfElementLocated(By.tagName("font")));

		if (!statusCheck.getText().contentEquals("Comparison Mismatch")) {
			// statusCheck.getText().contentEquals("Comparison Mismatch")){

			submitThePolicies(0);
		}
		if (driverIE.findElements(By.tagName("ul")).size() != 0) {

			submitThePolicies(0);

		}
		int m = 0;
		do {
			WebElement statusCheckInDo = (new WebDriverWait(driverIE, 10)).until(ExpectedConditions
					.presenceOfElementLocated(By.xpath("//*[@id='getresult']/tbody/tr/td[9]/nobr/font")));

			if (!statusCheckInDo.getText().contentEquals("System Error Regression(UM)")
					&& !statusCheckInDo.getText().contentEquals("System Error Field(UM)")
					&& !statusCheckInDo.getText().contentEquals("Comparison Mismatch")
					&& !statusCheckInDo.getText().contentEquals("No Difference")
					&& !statusCheckInDo.getText().contentEquals("Comparison Initiated")
					&& !statusCheckInDo.getText().contentEquals("System Error Baseline")
					&& !statusCheckInDo.getText().contentEquals("System Error Field")
					&& !statusCheckInDo.getText().contentEquals("System Error Regression")
					&& !statusCheckInDo.getText().contentEquals("System Error")
					&& !statusCheckInDo.getText().contentEquals("Passed")) {
				Thread.sleep(3000);
				System.out.println("Still in Refresh block");
				String presentStatusText = BlRegressionPage.presentStatus(0, driverIE).getText();
				System.out.println("Present Status of the Submitted Policy : " + presentStatusText);
				BlRegressionPage.refresh(driverIE).click();

			} else if (statusCheckInDo.getText().contentEquals("System Error Regression(UM)")
					|| statusCheckInDo.getText().contentEquals("System Error Field(UM)")
					|| statusCheckInDo.getText().contentEquals("Comparison Mismatch")
					|| statusCheckInDo.getText().contentEquals("No Difference")
					|| statusCheckInDo.getText().contentEquals("Comparison Initiated")
					|| statusCheckInDo.getText().contentEquals("System Error Baseline")
					|| statusCheckInDo.getText().contentEquals("System Error Field")
					|| statusCheckInDo.getText().contentEquals("System Error Regression")
					|| statusCheckInDo.getText().contentEquals("System Error")
					|| statusCheckInDo.getText().contentEquals("Passed"))

			{
				m++;
				System.out.println("now the status is : " + statusCheckInDo.getText());
			}

		} while (m < 1);
	}

	public void clickOnNextButton(WebElement elementProperty) {

		if (elementProperty.isDisplayed()) {

			elementProperty.click();
		}
	}

	public static void tearDownChrome() {
		if (driverChrome != null) {
			// System.out.println("EAR has been Validated");
			System.out.println("Closing Chrome browser");
			driverChrome.quit();
		}
	}

	public static void tearDownIE() {
		if (driverIE != null) {		
			System.out.println("Closing IE browser");
			driverIE.quit();

		}
	}

	public static void exceptionTearDown() {
		if (driverIE != null) {
			System.out.println("There is some problem with the Element and tear down needs to be done");
			System.out.println("Closing IE browser");
			driverIE.quit();

		}

		if (driverChrome != null) {
			System.out.println("Closing Chrome browser");
			driverChrome.close();
		}
	}

	public static void launchTheRequestCatalogURL() throws Exception {

		String url = "";
		url = catalogUrl;
		driverChrome.get(url);
		driverChrome.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	public int numberOfTotalReqests(int totalPages) throws InterruptedException {
		String closingDate = "";
		int counter = 0;
		int page = 2;
		int totalReqPresentInPage;
		for (int i = 1; i <= totalPages; i++) {

			totalReqPresentInPage = BlRegressionPage.closedRequestISEnvPageRows(driverChrome).size();
			for (int j = 2; j <= totalReqPresentInPage; j++) {

				closingDate = Action.driverChrome
						.findElement(By.xpath("//*[@id='tbl-false-0']/div[1]/table/tbody/tr[" + j + "]/td[6]"))
						.getText();

				if (!closingDate.contentEquals("02-27-2018 18:41:47")) {
					//
					counter++;

				}

				else if (closingDate.contentEquals("02-27-2018 18:41:47")) {

					break;
				}
			}
			// Action.driverChrome.findElement(By.xpath("//*[@id='reqPage-false-0-"+
			// page +"'" +"]/a")).click();
			// page++;

			if (closingDate.contentEquals("002-27-2018 18:41:47")) {

				break;

			} else if (!closingDate.contentEquals("02-27-2018 18:41:47")) {
				WebElement panel = driverChrome
						.findElements(By.cssSelector("[class='panel'] [class='pagination pull-right']")).get(0);
				WebElement nextButton = panel.findElement(By.xpath("//*[@id='reqPage-false-0-" + page + "']/a"));
				((JavascriptExecutor) driverChrome).executeScript("arguments[0].scrollIntoView(true);", nextButton);
				nextButton.click();
				page++;
			}

		}
		System.out.println("Number of Req raised = " + counter);
		System.out.println();

		return counter;
	}

	public String[] allRequestNumbers(int totalPages, int totalReq) {

		int reqNum = 0;
		int page = 2;
		int totalReqPresentInPage;
		String closingDate = "";
		String[] reqNumbers = new String[totalReq];
		for (int i = 1; i <= totalPages; i++) {

			totalReqPresentInPage = BlRegressionPage.closedRequestISEnvPageRows(Action.driverChrome).size();
			// System.out.println("total reersfregdebbcnsdmc s
			// "+totalReqPresentInPage);
			for (int j = 2; j <= totalReqPresentInPage; j++) {

				closingDate = Action.driverChrome
						.findElement(By.xpath("//*[@id='tbl-false-0']/div[1]/table/tbody/tr[" + j + "]/td[6]"))
						.getText();
				// System.out.println(closingDate);
				if (!closingDate.contentEquals("02-27-2018 18:41:47")) {
					reqNumbers[reqNum] = Action.driverChrome
							.findElement(By.xpath("//*[@id='tbl-false-0']/div[1]/table/tbody/tr[" + j + "]/td[1]/a"))
							.getText();
					// System.out.println(reqNumbers[reqNum]);
					reqNum++;

				}

				else if (closingDate.contentEquals("02-27-2018 18:41:47")) {
					break;
				}
			}

			if (closingDate.contentEquals("02-27-2018 18:41:47")) {

				break;
			}

			else if (!closingDate.contentEquals("02-27-2018 18:41:47")) {
				WebElement panel = driverChrome
						.findElements(By.cssSelector("[class='panel'] [class='pagination pull-right']")).get(0);
				WebElement nextButton = panel.findElement(By.xpath("//*[@id='reqPage-false-0-" + page + "']/a"));
				((JavascriptExecutor) driverChrome).executeScript("arguments[0].scrollIntoView(true);", nextButton);
				nextButton.click();
				page++;
			}

		}

		return reqNumbers;
	}

	public static void pressAltTab() {

		// elementProperty.get(46).click();
		Actions action = new Actions(driverChrome);
		action.sendKeys(Keys.chord(Keys.CONTROL, "T")).build().perform();

	}

	public static void raiseTheRequestForEAR(String url, int earFlag, String serverName, boolean isAlreadyRaised)
			throws Exception {

		boolean earStat = false;
		Action action = new Action();
		if (isAlreadyRaised == false) {
			Action.chromeSetUp();
			Action.launchTheRequestCatalogURL();
			Thread.sleep(5000);
			// WebDriverWait wait = new WebDriverWait(Action.driverChrome,20);
			// wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("gsft_main")));
			BlRegressionPage.viewAllItems(Action.driverChrome).click();
			BlRegressionPage.isEnv(Action.driverChrome).click();
			BlRegressionPage.innerISEnv(Action.driverChrome).click();
			BlRegressionPage.dcioPT(Action.driverChrome);
			Thread.sleep(2000);
			BlRegressionPage.areaOfBusinessPT(Action.driverChrome);
			Thread.sleep(2000);
			BlRegressionPage.platformLinux(Action.driverChrome);
			Thread.sleep(2000);
			BlRegressionPage.application(Action.driverChrome).click();
			BlRegressionPage.application(Action.driverChrome).sendKeys("Alliance");
			Thread.sleep(2000);
			BlRegressionPage.application(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ARROW_DOWN);
			BlRegressionPage.application(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ENTER);
			BlRegressionPage.selectServiceTask(Action.driverChrome).click();
			BlRegressionPage.calenderIcon(Action.driverChrome).click();
			Thread.sleep(2000);
			BlRegressionPage.selectPresentDate(Action.driverChrome).click();
			Thread.sleep(2000);
			BlRegressionPage.reportedReason(Action.driverChrome).sendKeys("On Server : " + serverName);
			BlRegressionPage.reportedReason(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ENTER);
			BlRegressionPage.reportedReason(Action.driverChrome).sendKeys(
					"Please make AutoBatchUtilsNonDeployEAR up, PropertyBatchUtilsNonDeployEAR up , MotorCycleBatchUtilsNonDeployEAR up and PersonalUmbrellaBatchUtilsNonDeployEAR up.");
			BlRegressionPage.reportedReason(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ENTER);
			BlRegressionPage.reportedReason(Action.driverChrome)
					.sendKeys("Note : If PropertyBatch is not coming up then bring PropertyNB Down.");
			BlRegressionPage.additionalReason(Action.driverChrome).sendKeys("On Server : " + serverName);
			BlRegressionPage.additionalReason(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ENTER);
			BlRegressionPage.additionalReason(Action.driverChrome).sendKeys(
					"Please make AutoBatchUtilsNonDeployEAR up, PropertyBatchUtilsNonDeployEAR up , MotorCycleBatchUtilsNonDeployEAR up and PersonalUmbrellaBatchUtilsNonDeployEAR up.");
			BlRegressionPage.additionalReason(Action.driverChrome).sendKeys(org.openqa.selenium.Keys.ENTER);
			BlRegressionPage.additionalReason(Action.driverChrome)
					.sendKeys("Note : If PropertyBatch is not coming up then bring PropertyNB Down.");
			Thread.sleep(2000);
			BlRegressionPage.orderRequest(Action.driverChrome).click();
			Thread.sleep(10000);
			Action.tearDownChrome();
			isAlreadyRaised = true;
			System.out.println("Request for EAR to make up has been raised. Please wait for some moment.");
		}

		do {
			Thread.sleep(200000);
			Action.chromeSetUp();
			earStat = action.launchTheEAR(url, earFlag);
			Action.tearDownChrome();

		} while (earStat == false);

	}

	public static void errorExecutionBlock(int stateNumber, String url, int earFlag, String wasServer,
			boolean isAlreadyRaised, String pageNumber) throws Exception {
		Action action = new Action();
		Thread.sleep(1000);
		List<String> controlNumber = new ArrayList<String>();
		controlNumber = action.getALLTheControlNumbers(Integer.parseInt(pageNumber));
		// Action.clearTheStatusFilter(BlRegressionPage.statusSystemErrorField(Action.driverIE));

		Action.clearTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE));
		BlRegressionPage.refresh(Action.driverIE).click();

		for (int i = 0; i < controlNumber.size(); i++) {

			System.out.println("Control Number to be Submit: " + controlNumber.get(i)
					+ " and the Submitted policy number out of total is: " + i);
			action.searchAndSubmitThePolicy(controlNumber.get(i));
			// action.checkForTheEARDown(0,url,earFlag,wasServer,isAlreadyRaised);
		}
		Action.clearTheSearchBox(BlRegressionPage.search(Action.driverIE));
		Action.clearTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE));
		Action.clearTheStateFilter(BlRegressionPage.clearStateFilter(Action.driverIE));
	}

	public void checkForTheEARDown(int policy, String url, int earFlag, String server, boolean isAlreadyRaised)
			throws Exception {
		Action action = new Action();

		String sysErrorClass = BlRegressionPage.presentStatus(policy, driverIE).getText();
		if (sysErrorClass.contentEquals("System Error Field(UM)")) {
			Thread.sleep(1000);
			WebElement diamondIcon = BlRegressionPage.lastSysErrorField(policy, Action.driverIE);
			JavascriptExecutor executor = (JavascriptExecutor) driverIE;
			executor.executeScript("arguments[0].click();", diamondIcon);
			Thread.sleep(1000);
			String errorDesc = BlRegressionPage.checkForTheErrorDescription(Action.driverIE).getText();
			if (errorDesc.contains("Error occured while calling web service")
					|| errorDesc.contains("Web Service is down")) {
				boolean earPresentStatus;
				Thread.sleep(300000);
				Action.chromeSetUp();
				earPresentStatus = action.launchTheEAR(url, earFlag);
				Action.tearDownChrome();
				if (earPresentStatus == false) {
					System.out.println("Need to raise the EAR Request. As it seems to be down");
					earFlag = 1;
					Action.raiseTheRequestForEAR(url, earFlag, server, isAlreadyRaised);
					earFlag = 0;
				}
			}

			Thread.sleep(1000);
			WebElement close = BlRegressionPage.closeButton(Action.driverIE);
			JavascriptExecutor executorClose = (JavascriptExecutor) driverIE; 
			executorClose.executeScript("arguments[0].click();", close); 
		
			Thread.sleep(1000); // WebDriver Interface
		}
	}

	public void submitTheErrorOfSameState(String url, int earFlag, String errorCode, String wasServer,
			boolean isAlreadyRaised) throws Exception {
		Action action = new Action();
		List<String> controlNumber = new ArrayList<String>();
		Action.searchByTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE), errorCode);
		// Action.selectSystemErrorField(BlRegressionPage.statusSystemErrorField(Action.driverIE));
		// BlRegressionPage.statusComparison(Action.driverIE).click();
		// Action.selectBlankStatus(BlRegressionPage.statusBlank(Action.driverIE));
		Action.selectSearchButton(BlRegressionPage.searchElement(Action.driverIE));
		String[] inErrorPagesNumbers = Action
				.getThePages(BlRegressionPage.numberOfPagesPresentElement(Action.driverIE));
		String pagesListNow[] = inErrorPagesNumbers;
		if (!pagesListNow[inErrorPagesNumbers.length - 3].contains("Previous")) {
			int pageNumber = Integer.parseInt(inErrorPagesNumbers[inErrorPagesNumbers.length - 3]);
			controlNumber = action.getALLTheControlNumbers(pageNumber);
			// Action.clearTheStatusFilter(BlRegressionPage.clearStatusFilter(Action.driverIE));
			Action.clearTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE));
			BlRegressionPage.refresh(Action.driverIE).click();

			for (int i = 0; i < controlNumber.size(); i++) {

				System.out.println("Control Number to be Submit: " + controlNumber.get(i)
						+ " and the Submitted policy number out of total is: " + i);
				action.searchAndSubmitThePolicy(controlNumber.get(i));
				action.checkForTheEARDown(0, url, earFlag, wasServer, isAlreadyRaised);
				// action.getTheErrorCodes(j,errorCodes,url,earFlag,server);

			}
			Action.clearTheSearchBox(BlRegressionPage.search(Action.driverIE));

		} else if (pagesListNow[inErrorPagesNumbers.length - 3].contains("Previous")) {

			// Action.clearTheStatusFilter(BlRegressionPage.clearFilter(Action.driverIE));
			Action.clearTheErrorCode(BlRegressionPage.errorCodeElement(Action.driverIE));
			Thread.sleep(1000);
		}
	}

/*	public static void submitTheTransactionAndRaiseEARIfDown(int stateNumber, String url, int earFlag, String server,
			boolean isAlreadyRaised, int presentProductFlag, int releaseWeek) throws Exception {
		Action action = new Action();
		// if(stateNumber == 4 || stateNumber == 46 ) {
		Thread.sleep(2000);
		// Action.selectTheState(stateNumber,BlRegressionPage.stateElement(Action.driverIE).get(stateNumber));
		BlRegressionPage.statusBlank(Action.driverIE).click();
		BlRegressionPage.stateElement(Action.driverIE).get(stateNumber).click();
		//String pageNumber = Action.getThePageNumbers();
		BlRegressionPage.searchElement(driverIE).click();
		if (!pageNumber.contains("Previous")) {
			int pageNum = Integer.parseInt(pageNumber);
			for (int i = 1; i <= pageNum; i++) {

				action.selectTheTransactionAndSubmit(stateNumber, pageNum, url, earFlag, server, isAlreadyRaised,
						presentProductFlag, releaseWeek);

	//		}
			Thread.sleep(1000);
		}
		BlRegressionPage.clearStatusFilter(Action.driverIE).click();
	
	}*/

	public static void policyExecutorBlock() throws Exception {
		boolean batch = false;
		do{
			 
			 if(Integer.parseInt(BlRegressionPage.testCaseCount(driverIE).getText()) >= 12){
		     BlRegressionPage.refreshButton(driverIE).click();
		     Thread.sleep(3000);
			 batch = false;
			 }
			 else {
				 batch = true;
			 }
			 
		}while(batch == false);	
		Action action = new Action();
		//if(String.valueOf(Action.checkBlank()).contains("Previous")){
/*			for(int i=0; i< num ; i++){			    
			    Thread.sleep(1000);	    
			   // BlRegressionPage.searchElement(driverIE).click();
			    action.selectTheTransactionAndSubmit();
			}*/
		//}
		boolean status = true;
		do{     
			    BlRegressionPage.statusBlank(Action.driverIE).click();
			    Thread.sleep(1000);	    
			    BlRegressionPage.searchElement(driverIE).click();
                action.selectTheTransactionAndSubmit();
                status = Action.checkForTheBlankStatus();
			    Thread.sleep(1000);
                
		}  while(status == true);

		 Thread.sleep(2000);
		// executeSystemErrorPolicies();		 
		 //BlRegressionPage.clearStatusFilter(Action.driverIE).click(); 
}
	
	public static void executeSystemErrorPolicies(){
		try {
			boolean batch = false;
			do{
				 
				 if(Integer.parseInt(BlRegressionPage.testCaseCount(driverIE).getText()) >= 12){
			     BlRegressionPage.refreshButton(driverIE).click();
			     Thread.sleep(3000);
				 batch = false;
				 }
				 else {
					 batch = true;
				 }
				 
			}while(batch == false);
			//boolean bool = true;
			Action action = new Action();
			Action.selectSystemErrorFailed(BlRegressionPage.systemErrorFailed(driverIE));
			BlRegressionPage.searchElement(driverIE).click();
    		String pageNumber = Action.getThePageNumbers();
			BlRegressionPage.clearStatusFilter(Action.driverIE).click();
/*    		if(!pageNumber.contains("Previous")){
			do{
			 String pagePresent = Action.getThePageNumbers();
			if (pagePresent.contains("Previous")) {
				bool = false;
			}
			else{
				action.selectTheTransactionAndSubmit();*/			
				int pageNum = Integer.parseInt(pageNumber);
				if(!pageNumber.contains("Previous")){
				for (int i = 1; i <= pageNum; i++) {
					Action.selectSystemErrorFailed(BlRegressionPage.systemErrorFailed(driverIE));
					BlRegressionPage.searchElement(driverIE).click();
					action.selectTheTransactionAndSubmit();
				}
			}
			//	}while(bool == true);
			//BlRegressionPage.clearStatusFilter(Action.driverIE).click();
			//BlRegressionPage.clearStateFilter(Action.driverIE).click();
			//}
		} catch (Exception e) {
			System.out.println(e);

		}
	}

	public static void policyInErrorExecutorBlock() throws Exception {
		

			String attribute = BlRegressionPage.selectStateHeaderTile(Action.driverIE).get(4)
					.getAttribute("aria-label");
			if (attribute.contentEquals("State: activate to sort column ascending")) {
				BlRegressionPage.selectStateHeaderTile(Action.driverIE).get(4).click();
			}			
		List<String> sateNames = new ArrayList<String>();
		Action.selectSystemErrorFailed(BlRegressionPage.systemErrorFailed(driverIE));		
		BlRegressionPage.searchElement(driverIE).click();
		String pageNumber = Action.getThePageNumbers();
		//Below is commented
		if (!pageNumber.contains("Previous")) {
			int pageNum = Integer.parseInt(pageNumber);
			for (int i = 1; i <= pageNum; i++) {
				int inPage =  BlRegressionPage.stateNames(driverIE).size();
				for(int j = 0; j< inPage; j++){
					int scroller = j;
				    if(scroller  >= inPage - 2){
					((JavascriptExecutor) driverIE).executeScript("arguments[0].scrollIntoView(true);",
							BlRegressionPage.stateNames(driverIE).get(scroller));
				    } 
					sateNames.add(BlRegressionPage.stateNames(driverIE).get(j).getText());
				}
				if (pageNum > 1) {
					BlRegressionPage.nextButton(driverIE).click();
				}											
			}			
		
		//commented
		BlRegressionPage.clearStatusFilter(Action.driverIE).click();
/*		BlRegressionPage.states(driverIE).selectByValue("AL");
		executeSystemErrorPolicies();*/
		LinkedHashSet<String> uniqeStates = new LinkedHashSet<String>(sateNames);
		//Action.selectSystemErrorFailed(BlRegressionPage.systemErrorFailed(driverIE));
		//BlRegressionPage.searchElement(driverIE).click();
		for (String s : uniqeStates) {
			BlRegressionPage.states(driverIE).selectByValue(s);
			//BlRegressionPage.searchElement(driverIE).click();
			System.out.println("Submit the control Numbers having errors in " + s + " State");
			executeSystemErrorPolicies();			
			//below should be clear state
			BlRegressionPage.clearStateFilter(Action.driverIE).click();
		}
	 }
	}

	public static void theProductTypeExecutionCompleted(int flag, int releaseWeek) throws InterruptedException {

		int actualReleaseWeek = releaseWeek;
		switch (flag) {

		case 1:
			System.out.println("All the Policies of Property for ReleaseWeek: " + ++actualReleaseWeek
					+ " has been executed Successfully.");
			break;
		case 2:
			System.out.println("All the Policies of Auto for ReleaseWeek: " + ++actualReleaseWeek
					+ " has been executed Successfully.");
			break;
		case 3:
			System.out.println("All the Policies of MotorCycle for ReleaseWeek: " + ++actualReleaseWeek
					+ " has been executed Successfully.");
			break;
		case 4:
			System.out.println("All the Policies of Personal Umbrella for ReleaseWeek: " + ++actualReleaseWeek
					+ " has been executed Successfully.");
			break;
		}
		BlRegressionPage.clearProductTypeFilter(Action.driverIE).click();
		Thread.sleep(1000);
	}

	public void getTheErrorCodes(int policy) throws InterruptedException {
		String sysErrorClass = BlRegressionPage.presentStatus(policy, driverIE).getText();
		if (sysErrorClass.contentEquals("System Error Field(UM)")) {
			Thread.sleep(1000);
			WebElement diamondIcon = BlRegressionPage.lastSysErrorField(policy, Action.driverIE);
			JavascriptExecutor executor = (JavascriptExecutor) driverIE;
			executor.executeScript("arguments[0].click();", diamondIcon);
			Thread.sleep(1000);
			String errorDesc = BlRegressionPage.checkForTheErrorDescription(Action.driverIE).getText();
			System.out.println("Error Description : " + errorDesc);
			if (errorDesc.contains(
					"Error occured while calling web service. Please try after sometime if the problem continues")
					|| errorDesc.contains("Web Service is down")) {

				System.out.println("Error occured while calling web service");
				errors.add(BlRegressionPage.checkForTheErrorCode(Action.driverIE).getText());

			} else if (errorDesc.contains("Rating calculation failed")
					|| errorDesc.contains("A Rate Control Mapping error occurred")) {

				System.out.println(
						"Some Web Service is down at the moment due to which we are getting error Rating calculation failed");
				errors.add(BlRegressionPage.checkForTheErrorCode(Action.driverIE).getText());

				Thread.sleep(10000);
			}

			else if (errorDesc.contains(
					"System was unable to process your request at this time. If the problem continues, please contact Technology Support")) {

				System.out.println("System was unable to process your request at this time.");
				errors.add(BlRegressionPage.checkForTheErrorCode(Action.driverIE).getText());
				Thread.sleep(10000);

			}

			Thread.sleep(1000);
			WebElement close = BlRegressionPage.closeButton(Action.driverIE);
			JavascriptExecutor executorClose = (JavascriptExecutor) driverIE;
			executorClose.executeScript("arguments[0].click();", close);
			// close.click();
			Thread.sleep(1000);
		}
	}

	public static String selectTheStatesForExecution() {
		String stateToSelect ="";
		try {

			String attribute = BlRegressionPage.selectStateHeaderTile(Action.driverIE).get(4)
					.getAttribute("aria-label");
			if (attribute.contentEquals("State: activate to sort column ascending")) {
				BlRegressionPage.selectStateHeaderTile(Action.driverIE).get(4).click();
			}
			if (BlRegressionPage.selectStateNameAtTop(Action.driverIE).get(0) != null) {
				stateToSelect = BlRegressionPage.selectStateNameAtTop(Action.driverIE).get(0).getText();				
				BlRegressionPage.states(driverIE).selectByValue(stateToSelect);  
/*				int totalStates = BlRegressionPage.stateElement(Action.driverIE).size();
				for (; i < totalStates; i++) {
					if (BlRegressionPage.stateElement(Action.driverIE).get(i).getText().substring(0, 2)
							.contentEquals(stateToSelect)) {
						break;
					}
				}*/
			}
		} catch (Exception e) {

		}

		return stateToSelect;
	}

	public static int checkBlank() throws InterruptedException {
		int pageNumber = 0;
		BlRegressionPage.statusBlank(Action.driverIE).click();
		BlRegressionPage.searchElement(Action.driverIE).click();
		Thread.sleep(2000);
		String[] pageNumbers = Action.getThePages(BlRegressionPage.numberOfPagesPresentElement(Action.driverIE));
		String pagesListNow[] = pageNumbers;
		if (!pagesListNow[pageNumbers.length - 3].contains("Previous")) {
			pageNumber = Integer.parseInt(pageNumbers[pageNumbers.length - 3]);		
			Thread.sleep(1000);
			BlRegressionPage.searchElement(Action.driverIE).click();
		}
		Thread.sleep(1000);
		BlRegressionPage.clearStatusFilter(Action.driverIE).click();
		return pageNumber;
	}

	public static boolean checkForTheBlankStatus() throws InterruptedException {
		boolean blank = false;
		int pages;
		Thread.sleep(2000);
		pages = Action.checkBlank();
		if (pages >= 1) {
			blank = true;
		}

		return blank;
	}

	public static boolean checkForTheEAR(String earToSelect, int earFlag) {
		Action action = new Action();
		boolean earUp = false;
		Action.chromeSetUp();	
		earUp = action.launchTheEAR(earToSelect, earFlag);
		Action.tearDownChrome();
		return earUp;
	}

	public static void selectTheProductTypeExecution(int presentProductFlag, String releaseWeek) {
		try {
			switch (presentProductFlag) {
			case 1:
				System.out.println("Start the Execution of Property Policies for Release Week : " + releaseWeek);					
				Thread.sleep(1000);
				Action.selectPropertyProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 2:
				System.out.println("Start the Execution of Auto Policies for Release Week : " + releaseWeek); 				       
				Thread.sleep(1000);
				Action.selectAutoProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 3:
				System.out.println("Start the Execution of Motorcycle Policies for Release Week : "  + releaseWeek);
				Thread.sleep(1000);
				Action.selectMotorProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 4:
				System.out.println("Start the Executin of PUP Policies for Release Week : " +releaseWeek);
				Thread.sleep(1000);
				Action.selectPUPProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;
			
			case 5: 
				System.out.println("Start the Executin of LPP Policies for Release Week : "  +releaseWeek);
				Thread.sleep(1000);
				Action.selectLPPProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;
			
			case 6:
				System.out.println("Start the Executin of Boat Policies for Release Week : "  +releaseWeek);
				Thread.sleep(1000);
				Action.selectBoatProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;
			
			case 7:
				System.out.println("Start the Executin of MFH Policies for Release Week : "  +releaseWeek);
				Thread.sleep(1000);
				Action.selectMFHProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				
			}
		} catch (Exception e) {
          
			System.out.println(e);
		}
	}

	public static boolean selectTheProductTypesExecution(int presentProductFlag, String earToSelect, int earFlag,
			int releaseWeek) {

		Action action = new Action();
		boolean earUp = false;
		Action.chromeSetUp();
		System.out.println(earToSelect);
		earUp = action.launchTheEAR(earToSelect, earFlag);
		Action.tearDownChrome();
		System.out.println();
		try {
			switch (presentProductFlag) {
			case 1:
				int propertyActualReleaseWeek = releaseWeek;
				System.out.println(
						"Start the Execution of Property Policies for Release Week : " + ++propertyActualReleaseWeek);
				Thread.sleep(3000);
				Action.selectPropertyProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 2:
				int autoActualReleaseWeek = releaseWeek;
				System.out
						.println("Start the Execution of Auto Policies for Release Week : " + ++autoActualReleaseWeek);
				Thread.sleep(3000);
				Action.selectAutoProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 3:
				int motorActualReleaseWeek = releaseWeek;
				System.out
						.println("Start the Execution of Moto Policies for Release Week : " + ++motorActualReleaseWeek);
				Thread.sleep(3000);
				Action.selectMotorProductType(BlRegressionPage.productTypeElement(Action.driverIE));
				break;

			case 4:
				int pupActualReleaseWeek = releaseWeek;
				System.out.println("Start the Executin of PUP Policies for Release Week :" + ++pupActualReleaseWeek);
				Thread.sleep(3000);
				Action.selectPUPProductType(BlRegressionPage.productTypeElement(Action.driverIE));
			}
		} catch (Exception e) {

		}
		return earUp;
	}

	public static String selectTheExecutionFlagGetThePresentEAR(int executionFlag, int presentProductFlag,
			String earToSelect, String impersonateUrlOfPresentWasServer) throws InterruptedException {

		switch (presentProductFlag) {
		case 1:
			earToSelect ="https://lxv3102.allstate.com:21143/PropertyNonProdAutomationWEB/rest/v3/ping";
			/*earToSelect = impersonateUrlOfPresentWasServer.substring(0, 29)
					+ "21143/PropertyNonProdAutomationWEB/rest/v3/ping";*/
			System.out.println(earToSelect);
			break;

		case 2:
			earToSelect ="https://lxv3102.allstate.com:21143/AutoNonProdAutomationWEB/rest/v3/ping";
/*			earToSelect = impersonateUrlOfPresentWasServer.substring(0, 29)
					+ "21143/AutoNonProdAutomationWEB/rest/v3/ping";*/
			System.out.println(earToSelect);
			break;

		case 3:
			earToSelect = "https://lxv3102.allstate.com:21143/MotorcycleNonProdAutomationWEB/rest/v3/ping";
			System.out.println(earToSelect);
			break;

		case 4:
			earToSelect =  "https://lxv3102.allstate.com:21143/PersonalUmbrellaNonProdAutomationWEB/rest/v3/ping";
			System.out.println(earToSelect);
			break;
		
		case 5:
			earToSelect =  "https://lxv3102.allstate.com:21143/LandlordNonProdAutomationWEB/rest/v3/ping";
			System.out.println(earToSelect);
            break;
            
		case 6:
			earToSelect =  "https://lxv3102.allstate.com:21143/BoatNonProdAutomationWEB/rest/v3/ping";
			System.out.println(earToSelect);
			break;
			
		case 7:
			earToSelect =  "https://lxv3102.allstate.com:21143/ManufacturedhomeNonProdAutomationWEB/rest/v3/ping";
			System.out.println(earToSelect);	
		}
		return earToSelect;
	}

	public static String getThePageNumbers() throws InterruptedException {

		Action.selectSearchButton(BlRegressionPage.searchElement(Action.driverIE));
		Thread.sleep(2000);
		String[] pageNumbers = Action.getThePages(BlRegressionPage.numberOfPagesPresentElement(Action.driverIE));
		String pagesList[] = pageNumbers;
		return pagesList[pageNumbers.length - 3];
	}

	public static void altNMethod(Robot robot) throws InterruptedException {

		robot.keyPress(KeyEvent.VK_ALT);		
		robot.keyPress(KeyEvent.VK_N);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_N);
		robot.keyRelease(KeyEvent.VK_ALT);		
	}
	
	public static void ctrlRMethod(Robot robot) throws InterruptedException {

		robot.keyPress(KeyEvent.VK_CONTROL);		
		robot.keyPress(KeyEvent.VK_R);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_R);
		robot.keyRelease(KeyEvent.VK_CONTROL);		
	}
	
	public static void refreshMethod(Robot robot) throws InterruptedException {

		robot.keyPress(KeyEvent.VK_F5);				
		Thread.sleep(1000);
		robot.keyRelease(KeyEvent.VK_F5);
				
	}
	public static void tabMethod(Robot robot)  {
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
	}
	
	public static void keyDownMethod(Robot robot)  {
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
	}
	public static void keyEnterMethod(Robot robot)  {
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}
	public static void altDMethod(Robot robot) throws InterruptedException  {
		robot.keyPress(KeyEvent.VK_ALT);
		robot.keyPress(KeyEvent.VK_D);
		Thread.sleep(2000);
		robot.keyRelease(KeyEvent.VK_D);
		robot.keyRelease(KeyEvent.VK_ALT);
	}
	
	public static WebElement date (WebDriver driver) {
		
		WebElement stat =  driver.findElement(By.xpath("//input[@id='filterStartDate']"));
	   	
		//stat.sendKeys("value", "your value");
		return stat;

   }
}
