package Global_Function_Lib;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Utility {
	
	
	public static void captureScreenshot(WebDriver driver , String screenShotName){
	try{
		
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFileToDirectory(source, new File("./Screenshots/"+screenShotName+System.currentTimeMillis()+".png"));
	  			
	
	 }
	catch(Exception e){
	   	
	   System.err.println(e.getMessage());
	   
	  }
	}		
}