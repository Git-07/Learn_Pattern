package Global_Function_Lib;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;

public class Excel_Data {
	static int number;
	static String textValue = "";
	static int colIndex;
	static int flagIndex;
	static int rowNum;
	static int rowIndex;
	static boolean booleanValue;
	static XSSFCell cell;
	static XSSFRow row;
	static String data = "";
	static int totalRows = 0;
	static List<Integer> rowNumFail = new ArrayList<Integer>();

	public static void setTheNumericValue(int val) {
		number = val;
	}

	public static String getTheNumericValue() {
		return String.valueOf(number);
	}

	public static void setTheStringValue(String str) {
		textValue = str;
	}

	public static String getTheStringValue() {
		return textValue;
	}

	public static void setTheBooleanValue(boolean bool) {
		booleanValue = bool;
	}

	public static String getTheBooleanValue() {
		return String.valueOf(booleanValue);
	}

	public static int getExcelRows(int sheetIndex, String path) {
		try {
			InputStream input = new FileInputStream(path);
			XSSFWorkbook wb = new XSSFWorkbook(input);
			XSSFSheet sheet = wb.getSheetAt(sheetIndex);
			totalRows = sheet.getPhysicalNumberOfRows();
			wb.close();
		} catch (Exception e) {

		}
		return totalRows;
	}

	public static String getExcelData(String testCaseId, int sheetIndex, String colName, String path) throws Exception {

		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		//totalRows = sheet.getPhysicalNumberOfRows();
		Iterator<Row> rows = sheet.rowIterator();		
		while (rows.hasNext()) {
			// Row -> it is an interface;
			// row = rows.next();
			row = (XSSFRow) rows.next();			
			if (row.getRowNum() == 0) {

				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					if (cell.getStringCellValue().equals(colName)) {
						colIndex = cell.getColumnIndex();

					}
				}
			} else if (row.getRowNum() != 0) {
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();
				if (cell.getStringCellValue().contentEquals(testCaseId)) {
					try {

						while (cell.getColumnIndex() != colIndex) {
							cell = (XSSFCell) cells.next();
						}
						switch (cell.getCellType()) {

						case XSSFCell.CELL_TYPE_NUMERIC:
							setTheNumericValue((int) cell.getNumericCellValue());
							data = getTheNumericValue();
							break;
						case XSSFCell.CELL_TYPE_STRING:
							setTheStringValue(cell.getStringCellValue());
							data = getTheStringValue();
							break;
						case XSSFCell.CELL_TYPE_BOOLEAN:
							setTheBooleanValue(cell.getBooleanCellValue());
							data = getTheBooleanValue();
							break;

						case XSSFCell.CELL_TYPE_BLANK:
                            data = "";
						}
					} catch (Exception e) {
						//data = "null";

					} finally {
						wb.close();
					}
				}

			}
		}

		return data;
	}

	// use below
	public static List<String> getTheExcelData(int sheetIndex, String colName, String path) throws Exception {
		List<String> list = new ArrayList<String>();
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		totalRows = sheet.getPhysicalNumberOfRows();
		Iterator<Row> rows = sheet.rowIterator();

		while (rows.hasNext()) {
			row = (XSSFRow) rows.next();
			if (row.getRowNum() == 0) {

				Iterator<Cell> cells = row.cellIterator();
				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					if (cell.getStringCellValue().equals(colName)) {
						colIndex = (int) cell.getColumnIndex();					
					}
				}
			} 
			else if (row.getRowNum() != 0) {
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();

				try {
					while (cell.getColumnIndex() != colIndex) {
						cell = (XSSFCell) cells.next();
					}
					switch (cell.getCellType()) {

					case XSSFCell.CELL_TYPE_NUMERIC:
						list.add(String.valueOf(cell.getNumericCellValue()));
						break;
					case XSSFCell.CELL_TYPE_STRING:
						list.add(cell.getStringCellValue());
						break;
					case XSSFCell.CELL_TYPE_BOOLEAN:
						list.add(String.valueOf(cell.getBooleanCellValue()));
						break;

					case XSSFCell.CELL_TYPE_BLANK:
						//list.add(String.valueOf(""));
					}
				} catch (Exception e) {
					
					//System.out.println(e);

				} finally {
					wb.close();
				}
			}

		}
	
		return list;
		
	}

	public static void writeExcelData(int sheetIndex, String sheetName, List<String> str, List<ArrayList<String>> pending,
			String path) throws Exception {

		int i = 0;
		XSSFWorkbook wb;
		XSSFSheet sheet;
		InputStream input = new FileInputStream(path);
		if (sheetIndex >= 1) {
			wb = new XSSFWorkbook(input);
			sheet = wb.getSheetAt(sheetIndex);
		} else {
			wb = new XSSFWorkbook(input);
			sheet = wb.createSheet(sheetName);
		}
		row = sheet.createRow(i++);
		for (int j = 0; j < str.size(); j++) {

			row.createCell(j).setCellValue(str.get(j));
			sheet.setColumnWidth(j, 30 * 250);
		}

		for (int r = 0; r < pending.get(0).size(); r++) {
			row = sheet.createRow(i++);
			for (int k = 0; k < str.size(); k++) {
			
				row.createCell(k).setCellValue(pending.get(k).get(r));
			
			}
		}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);
		fileOut.close();
		wb.close();
	}

	public static void setColorToCell(int sheetIndex, int columnIndex, List<Integer> rowNumsList, String path)
			throws IOException {

		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		Iterator<Row> rows = sheet.iterator();
		while (rows.hasNext()) {
			CellStyle style = wb.createCellStyle();
			row = (XSSFRow) rows.next();
			for (int i = 0; i < rowNumsList.size(); i++) {
				if (row.getRowNum() == rowNumsList.get(i) + 1) {
					style.setFillBackgroundColor(IndexedColors.GREEN.getIndex());
					style.setFillPattern((short) 2);
					Iterator<Cell> cells = row.cellIterator();
					cell = (XSSFCell) cells.next();
					while (cell.getColumnIndex() != columnIndex) {
						cell = (XSSFCell) cells.next();
					}
					cell.setCellStyle(style);
					break;
				}
			}
		}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);
		fileOut.close();
		wb.close();
	}
	
	public static void writeToExcelData(int presentRows,int sheetIndex,int columnIndex, ArrayList<ArrayList<String>> str, String path) throws IOException{
		int i = presentRows;
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb =  new XSSFWorkbook(input);
		XSSFSheet sheet;
		sheet = wb.getSheetAt(sheetIndex);
		//FileOutputStream fileOut = new FileOutputStream("C:\\Users\\mlatw\\Desktop\\Policies");
		//InputStream input = new FileInputStream("C:\\Users\\mlatw\\Desktop");	    
		
		for (int r = 0; r <str.get(0).size(); r++) {
			row = sheet.createRow(i++);
			for ( int j = 0; j< str.size() ; j ++){	

			row.createCell(j).setCellValue(str.get(j).get(r));
			}
			//row = sheet.createRow(i++);
		}
		FileOutputStream fileOut = new FileOutputStream(path);
		
		wb.write(fileOut);	
		fileOut.close();
		wb.close();
		
	}
	
	public static void writeRequestToExcelData(int sheetIndex,int columnIndex, ArrayList<String> str, String path) throws IOException{
        int i = 0;
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb =  new XSSFWorkbook(input);
		XSSFSheet sheet;
		sheet = wb.getSheetAt(sheetIndex);
		for (int r = 0; r <str.size(); r++) {
			row = sheet.createRow(i++);
			
			row.createCell(columnIndex).setCellValue(str.get(r));		
			
		}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);	
		fileOut.close();
		wb.close();
		
	}
	
	public static List<String> getRowExcelData(List<Integer> rowNum, int sheetIndex, int colIndex, String path) throws Exception {

		List<String> geoBoxDetails = new ArrayList<String>();
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		totalRows = sheet.getPhysicalNumberOfRows();
		Iterator<Row> rows = sheet.rowIterator();
		while (rows.hasNext()) {
			// Row -> it is an interface;
			// row = rows.next();
			row = (XSSFRow) rows.next();			
//			if (row.getRowNum() == rowNum.) {*/
				for(int i =0 ;i< rowNum.size() ; i++){
					if(row.getRowNum() == rowNum.get(i)){
						Iterator<Cell> cells = row.cellIterator();
						cell = (XSSFCell) cells.next();

			/*			try {
							while (cell.getColumnIndex() != colIndex) {
								cell = (XSSFCell) cells.next();
							}*/
			  
	//			  while (cells.hasNext()) {
/*					cell = (XSSFCell) cells.next();
					if (cell.getStringCellValue().equals(colName)) {
						colIndex = cell.getColumnIndex();*/

				
				//}
/*			} else if (row.getRowNum() != 0) {
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();
				if (cell.getStringCellValue().contentEquals(testCaseId)) {*/
					try {
					    //Iterator<Cell> cells = row.cellIterator();
					    
						while (cell.getColumnIndex() != colIndex) {
							cell = (XSSFCell) cells.next();
						}
						switch (cell.getCellType()) {

						case XSSFCell.CELL_TYPE_NUMERIC:
							setTheNumericValue((int) cell.getNumericCellValue());
							geoBoxDetails.add(getTheNumericValue());
							break;
						case XSSFCell.CELL_TYPE_STRING:
							setTheStringValue(cell.getStringCellValue());
							geoBoxDetails.add(getTheStringValue());
							break;
						case XSSFCell.CELL_TYPE_BOOLEAN:
							setTheBooleanValue(cell.getBooleanCellValue());
							geoBoxDetails.add(getTheBooleanValue());
							break;

						case XSSFCell.CELL_TYPE_BLANK:
							geoBoxDetails.add("");
						}
					} catch (Exception e) {
						

					} finally {
						wb.close();
					}
			}
		}
		}
		return geoBoxDetails;
	}
}
