package JavaCollections;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class HashMapUsage {
	static XSSFCell cell;
	static XSSFRow row;
	static String path = "C:\\Users\\mlatw\\Desktop\\Policies.xlsx";

	
public static void writeRequestToExcelData(HashMap<String,String> map) throws IOException{        
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb =  new XSSFWorkbook(input);
		XSSFSheet sheet;
		sheet = wb.getSheetAt(0);
		int  i = 0;
			Set<String> keyset = map.keySet();
			for(String key : keyset){
				row = sheet.createRow(i++);
				//row = sheet.getRow(i++);
				row.createCell(0).setCellValue(key);
				row.createCell(1).setCellValue(map.get(key));
			}
		FileOutputStream fileOut = new FileOutputStream(path);
		wb.write(fileOut);	
		fileOut.close();
		wb.close();
		
	}

public static void main(String[] ar) throws IOException{

	 HashMap<String,String> map = new HashMap<String, String>();
    map.put("TC_01", "Pass");
    map.put("TC_02", "Fail");
    map.put("TC_03", "Pass");
    map.put("TC_04", "Pass");
    map.put("TC_05", "Pass");
    map.put("TC_06", "Fail");
    map.put("TC_07", "Pass");

	writeRequestToExcelData(map);
	System.out.println("done");
}

}
