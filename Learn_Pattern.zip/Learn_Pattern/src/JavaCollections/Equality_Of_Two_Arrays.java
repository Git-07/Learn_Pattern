package JavaCollections;
import java.util.*;

public class Equality_Of_Two_Arrays {
	
	public static void main(String[] args){
		//to be done when dealing with String input or String Array
	/*	String [] str1 = {"One", "One","Two","Three","Three","Four","Five","Five","Six"};
		String [] str2= {"One", "One","Two","Three","Three","Four","Five","Five","Six","seven"};
		
		LinkedHashSet<String> set1 = new LinkedHashSet<String>(Arrays.asList(str1));
		LinkedHashSet<String> set2 = new LinkedHashSet<String>(Arrays.asList(str2));
		set1.removeAll(set2);
		if(set1.size()>= 0 && set2.size() != str1.length){
			System.out.println("not equal");
			System.out.println(set2);
		}
		else if(set1.size() == 0 && set2.size() == str1.length)
		{
			System.out.println("equal");
		}
		*/
		// other way of doing is sorting and using Array.equals method
	/*	String [] str1 = {"One", "One","Two","Three","Three","Four","Five","Five","Six"};
		String [] str2= {"One", "One","Two","Three","Three","Four","Five","Five","Six","seven"};
		Arrays.sort(str1);
		Arrays.sort(str2);
		if(Arrays.equals(str1,str2)){
			System.out.println("Arrays are equal");
		}
		else{
			System.out.println("Arrays are not equal");
		}
		*/
		int[] a = {1,2,3,4,7,8};
		int[] b = {1,3,4,7,82};
		Arrays.sort(a);
		Arrays.sort(b);
		if(Arrays.equals(a, b)){
			System.out.println("Arrays are equal");
		}
		else{
			System.out.println("Arrays are not equal");
		}
		
}
}