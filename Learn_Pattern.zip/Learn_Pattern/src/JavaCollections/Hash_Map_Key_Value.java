package JavaCollections;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
//import java.util.Map.Entry;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Hash_Map_Key_Value {
	static int number;
	static String textValue = "";
	static int colIndex;
	static int flagIndex;
	static int rowNum;
	static int rowIndex;
	static boolean booleanValue;
	static XSSFCell cell;
	static XSSFRow row;
	static String data = "";
	static int totalRows;
	static ArrayList<String> colData = new ArrayList<String>();
	  static List<String> testCaseIDs = new ArrayList<String>();
	  static List<String> requiredColumn = new ArrayList<String>();

	public static void setTheNumericValue(int val) {
		number = val;
	}

	public static String getTheNumericValue() {
		return String.valueOf(number);
	}

	public static void setTheStringValue(String str) {
		textValue = str;
	}

	public static String getTheStringValue() {
		return textValue;
	}

	public static void setTheBooleanValue(boolean bool) {
		booleanValue = bool;
	}

	public static String getTheBooleanValue() {
		return String.valueOf(booleanValue);
	}
	
	public Map<String,String> getTheMappedValue(int sheetIndex,String tcId,String col1 ,String col2 ,String path) throws Exception { // here key will be test case id
		
		String c = null;
        List<String> key = new ArrayList<String>();
		Map<String, String> record = new HashMap<String, String>();
		testCaseIDs = getExcelDataForHashMap(sheetIndex, col1, path);
		 for(int i=0 ;i<testCaseIDs.size(); i++){
             key.add(testCaseIDs.get(i));					 
		}

		System.out.println("Below are the details of the records");
		requiredColumn = getExcelDataForHashMap(sheetIndex, col2, path);
		try{
		} catch (Exception e) {

			e.printStackTrace();
		}
		finally{
			
		}

		for(int i =0 ; i< key.size() ;i++){
			record.put(key.get(i), requiredColumn.get(i));			
		}
		for (Map.Entry<String, String> pair : record.entrySet()) {		
			//if(pair.getKey().equals(tcId)){
			System.out.println(pair.getKey() + "->" + pair.getValue());
			c= pair.getValue();
							
		 //}
		}
		System.out.println(record.get(key.get(5)));
		//System.out.println(record);
		return record;
		
		
	}

	public static void main(String[] ar) throws Exception {

		try{
			
			Hash_Map_Key_Value hasm = new Hash_Map_Key_Value();
			hasm.getTheMappedValue(0,"TC_06","Test" , "Company" ,"C:\\Users\\mlatw\\Desktop\\Test_Data.xlsx");
			
		} catch (Exception e) {

			e.printStackTrace();
		}
		finally{
			
		}
	}
	
	public static ArrayList<String> getExcelDataForHashMap(int sheetIndex, String colName, String path) throws Exception {
		colData.clear();
		InputStream input = new FileInputStream(path);
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(sheetIndex);
		totalRows = sheet.getPhysicalNumberOfRows();
		Iterator<Row> rows = sheet.rowIterator();
		totalRows = sheet.getLastRowNum();

		while (rows.hasNext()) {
			row = (XSSFRow) rows.next(); // row is type of XSSFRow & rows.next()
											// is type Row

			if (row.getRowNum() == 0) {
				Iterator<Cell> cells = row.cellIterator();

				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();

					if (cell.getStringCellValue().equals(colName)) {
						{
							colIndex = cell.getColumnIndex();
                         //   System.out.println("dwksvbckhswdvb " + colIndex);                            
						}
					}
				}
							
				
				
			} else if (row.getRowNum() != 0) {
				Iterator<Cell> cells = row.cellIterator();
				cell = (XSSFCell) cells.next();
					try {
						while (cell.getColumnIndex() != colIndex) {
							cell = (XSSFCell) cells.next();
						}
					if (cell.getColumnIndex() == colIndex) {     
						
						switch (cell.getCellType()) {
                       
						case XSSFCell.CELL_TYPE_NUMERIC:                                
							setTheNumericValue((int) cell.getNumericCellValue());
							data = getTheNumericValue();
							colData.add(getTheNumericValue());
							break;
						case XSSFCell.CELL_TYPE_STRING:	
							setTheStringValue(cell.getStringCellValue());
							data = getTheStringValue();
							colData.add(getTheStringValue());
							break;
						case XSSFCell.CELL_TYPE_BOOLEAN:
							setTheBooleanValue(cell.getBooleanCellValue());
							data = getTheBooleanValue();
							colData.add(getTheBooleanValue());
/*							break;
						case XSSFCell.CELL_TYPE_BLANK:
                         System.out.println("I reached here");*/
						}
						
					}
				}		
			
					catch (Exception e) {	
						colData.add("null");
						
					} finally {						
						wb.close();
					}
				}
			}
		
		return colData;
	}	
}
