package JavaCollections;
import java.util.*;
//** Collections is the Utility class in Java having static methods only ***//
public class Sort_Using_Collections {
	
	public static void main(String[] ar){
		
		List<Integer> arrayList = new ArrayList<Integer>();
		arrayList.add(3);
		arrayList.add(2);
		arrayList.add(11);
		arrayList.add(8);
		arrayList.add(9);
		arrayList.add(1);				

	//Comparator compare = Collections.reverseOrder(); 
		// this method returns an object of Comparator type used only in case of descending order
	Collections.sort(arrayList,Collections.reverseOrder()); 
	// if we need to make the sort in ascending order just pass arrayList object parameter only
	System.out.println(arrayList);
  }
}



