package Same_Array_Pattern;

public class Sort_String {
	
	static String str = "ABCDABCD";	
	static char temp;
	
	public static void main(String[] ar){
	char[] ch = str.toCharArray();
	
	for(int i =0; i<ch.length ;i++){
		
		for(int j = i+1 ; j<ch.length ; j++){
			
			if((int) ch[i] > (int)ch[j]){
				
				temp = ch[i];
				ch[i] = ch[j];
				ch[j] = temp;
			} 
		}		
	}	
	System.out.print(str.valueOf(ch));
	//System.out.print((char) 65);
}

}
