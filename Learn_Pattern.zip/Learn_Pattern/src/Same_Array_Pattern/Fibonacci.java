package Same_Array_Pattern;

public class Fibonacci {
	
	
	public static void main(String[] ar){
		int n = 6;
		int previous = 1;
		int next =1;
		int fibonacci = 1;
		
		for(int i = 1; i<=n ; i++){
			
			if( i <= 2){
				System.out.print(1 + " ");
			}
			else{		
				fibonacci = previous + next;
				previous = next;
				next = fibonacci;
		        System.out.print(fibonacci + " ");		
		   }		
	}
		
}

}
