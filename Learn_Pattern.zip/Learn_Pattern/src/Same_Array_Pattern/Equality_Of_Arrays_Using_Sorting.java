package Same_Array_Pattern;

public class Equality_Of_Arrays_Using_Sorting {
	
	 static String temp;	
     public static void getTheSortedArray(String str[]){
		for(int i=0; i<str.length ; i++){	
			for(int j = i+1 ; j<str.length ;j++ ){
			  if(str[i].compareToIgnoreCase(str[j])> 0){		

					temp = str[i];
					str[i] = str[j];
					str[j] = temp;	
			  }
		}
		//	System.out.println(str[i]);
		}	  
   }
   
	public static void main(String[] ar){
		
		String[] str1 = {"Today","is","Monday","Monday"};
		String[] str2 = {"Monday","is","Monday","Monday"};
		int flag = 0;
		if(str1.length != str2.length){
			System.out.println("Arrays are not equal");
		}
		else{
			getTheSortedArray(str1);
			getTheSortedArray(str2);

		for(int k = 0 ; k< str1.length ;k++){

			if(str1[k] == str2[k]){
				flag = 1;
			}
			else{
				
				flag = 2;
				break;
			}
		  }
		if(flag == 1){
			
			System.out.println("Arrays are equal");
		   }
		
		else if(flag == 2){
			
			System.out.println("Arrays are not equal");
		   }
		}
		
	}

}
