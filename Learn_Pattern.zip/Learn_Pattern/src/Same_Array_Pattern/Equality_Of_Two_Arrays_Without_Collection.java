package Same_Array_Pattern;

public class Equality_Of_Two_Arrays_Without_Collection {
	
	//String array is  rotated version
	public static void main(String[] ar){
		
		String[] str1 = {"is","Today","Today","Monday"};
		String[] str2 = {"Monday","is","Today","Today"};
		int flag =0;
		int counter1 = 0;
		int counter2 = 0;
		if(str1.length != str2.length){			
			System.out.println("The String arrays are not equal");

		}
		else {
		for(int i=0 ; i<str1.length; i++){
/*			if(str1.length != str2.length){
			
				System.out.println("The String arrays are not equal");
				break;
			}
			else {*/
			for(int j = 0; j<str2.length; j++){
				
				if(!str1[i].equals(str2[j])){
					flag = 1;
					
				}
				else if(str1[i].equals(str2[j])){
					for(int l = 0 ; l< str1.length ; l++){
					   if(str1[i] == str1[l]){
						   counter1++;
						   
					   }					  
					}
					for(int m = 0 ; m< str2.length ; m++){
						if(str2[j] == str2[m]){
							   counter2++;
						   }
					}
					System.out.println(counter1);
					System.out.println(counter2);					
					if(counter1 == counter2){
                    flag = 2;
                    //break;
                     counter1=0;counter2=0;
					}

				}								 
			}
			if(flag == 1){
				break;
			}
			
			
		}}
		
			if(flag == 1){	
				System.out.println("The String arrays are not equal");
			//	break;
			}
	 //  }
		if(flag == 2){
			System.out.println("The String arrays are equal");
		}
	}
}
