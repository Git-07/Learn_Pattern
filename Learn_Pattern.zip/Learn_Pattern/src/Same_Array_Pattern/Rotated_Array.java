package Same_Array_Pattern;

public class Rotated_Array {

	public static void main(String[] ar){
		
		int num [] = {1,2,3,4,5,6,7,8,9};
		int temp;
		int index = 2;
		
        for(int i = 0; i< index; i++){
			
			temp = num[0];
				
		for(int j = 0; j< num.length -1 ;j ++){
			
		  num[j] = num[j +1];				
		}
		  
		  num[num.length - 1] = temp;
     }
		for(int k = 0 ; k< num.length ; k++){
			System.out.print(num[k]);
		}
	} 
}
