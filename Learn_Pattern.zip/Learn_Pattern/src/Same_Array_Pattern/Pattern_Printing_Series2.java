package Same_Array_Pattern;


public class Pattern_Printing_Series2 {
	
	static int counter = 1;
	public static void main(String[] ar){
		
		for(int r = 1 ; r <= 4; r++){
			
			for(int j = r ; j<4 ;j++){
				System.out.print(" ");
			}
			
			for(int c = 1 ; c<= r ;c++){
				
				System.out.print(counter++);
				System.out.print(" ");
			}
			System.out.println();
		}
	}	   
}
