package Same_Array_Pattern;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Data_Table {
	
	//below is the basic way to enter data to a data table
	/*public static void dataEnter(String empId, String name ,String salary){
		System.out.print(empId + "  " + name + " " + salary);		
		System.out.println();
	} 
	
	public static void main(String[] ar){
		System.out.println("EmpId" + "  " + "Name" + "  "  + "Salary");
		dataEnter("100","Edward","10000");
		dataEnter("101","Andy","20000");
		dataEnter("102","James","30000");
	} */
public static void main(String[] are){
	List<String> headers = new ArrayList<String>();
/*	headers.add("EmpId");
	headers.add("Name");
	headers.add("Salary");
	headers.add("100");
	headers.add("Edward");
	headers.add("10000");
	headers.add("101");
	headers.add("Jos");
	headers.add("20000");*/
	for(int i =0 ; i < headers.size();){
	   
		for(int j = i; j<i+3;j++){
		System.out.print(headers.get(j) + "  ");		
		
		}
		System.out.println();
		i = i + 3;
	}
    //ArrayList<String> data = new ArrayList<String>();
    //data.add();
  }
}
