package Same_Array_Pattern;

public class Palindrome_Number {
	
	public static void main(String[] ar){
		
		int number  = 1001;
		int reverse = 0;
		int temp = number;
		while(temp>0){
			
			int remainder = temp%10;
			reverse = reverse*10 + remainder;
			temp = temp/10;
		}
	    System.out.println(reverse);
	    System.out.println(number);
		if(number == reverse){
			System.out.println("Number is Palindrome");
		}
		else{
			System.out.println("Number is not Palindrome");
		}
	}
}
