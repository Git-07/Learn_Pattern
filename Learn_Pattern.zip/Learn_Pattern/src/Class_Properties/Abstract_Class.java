package Class_Properties;

public abstract class Abstract_Class {
	
	public  void implementMethodInAbstract(){
		
	}

}
