package Enum_Study;

interface inter {
	 
	void getTheValue();
}

public class EnumLearn {
	//enum may implement many interfaces but cannot extend any class because it internally extends Enum
	//order will be maintained in Enums
	public static enum Season implements inter {   
		Winter(1),                                  
		Summer(10.05226),
		Spring(21.22),
		Fall("20"),
		MidSummer("Its Too Hot"),	
		AfterSummer("Spring Season will come");
	
	private String str;
	private int value;
	private double values;
	private Season(double val){		
		this.values = val;		
	}
	
	private Season(int value){
	this.value= value;	
	}
	
	private Season(){
		System.out.println("inside constructor 2");
	}
	
	private Season(String s){
		this.str = s;
	}
	public void getTheValue(){
		System.out.println("javacjavacjavacjavac");
		
	}	
}	
	public static void main(String [] args){
		
		for(Season s : Season.values()){
	  //Season s = Season.Summer;		
			switch (s){				
			case Winter:
				System.out.println(s + " " +s.value);				
			    break;
			case Summer:
				System.out.println(s + "  " +s.values);
			    break;
			case Spring:
				 System.out.println(s + "  " +s.values);
				 break;
			case MidSummer:
				System.out.println(s + "  " +s.str);
				break;
			case AfterSummer:
				System.out.println(s + "  " +s.str);
				break;
			case Fall:
				System.out.println(s + "  " +s.str);
			}
		}
	  }
  }
	
