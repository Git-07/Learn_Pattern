package Pattern_Sequence;
import java.util.*;
import java.util.Map.*;
public class EachCharacterOccurenceCount {
	//HashMap does not maintain the insertion order
	//LinkedHashMap maintain the insertion order
	//HashMap and LinkedHashMap both are unsynchronized
	public static void main(String[] a){
	
		String sentence = "Today is Monday Today is Monday Today is Monday";
		char [] words = sentence.replace(" ", "").toCharArray();
		String[] wordsInSentence = sentence.split("\\s+");
	//	HashMap<Character,Integer> word = new HashMap<Character,Integer>();
/*		for(char w : words){			
			if(word.containsKey(w)){
				
				word.put(w, word.get(w) + 1);
			}	
			else
			{
			
				word.put(w, 1);
			}				
		}	
		Set<Character> wordsInChar = word.keySet();
		
		for(Character wo : wordsInChar){
           
			System.out.println(wo + " : " + word.get(wo));
           
		}
		
		Set<Entry<Character,Integer>> enteries = word.entrySet();
		System.out.println(enteries); 		
		//LinkedHashMap		
		Map<Character,Integer> word1 = new LinkedHashMap<Character,Integer>();
        for(char w: words){
        	
        	if(word1.containsKey(w)){
        		word1.put(w, word1.get(w) + 1);
        	}
        	else {
        		word1.put(w, 1);
        	}        	
        }         [is=3, Today=3, Monday=3]
      Set<Entry<Character,Integer>> mp = word1.entrySet();
      System.out.println(mp);*/
      
/*     Map<String,Integer> word3 = new HashMap<String,Integer>();
      for(String s: wordsInSentence){
    	  if(word3.containsKey(s)){
    		  word3.put(s, word3.get(s) + 1);
    	  }
    	  else{
    		  word3.put(s,1);
    	  }
      }
      Set<Entry<String,Integer>> hasT = word3.entrySet();
      System.out.println(hasT);
      */
/*     HashMap<String,Integer> word = new LinkedHashMap<String,Integer>();
      for(String wrd : wordsInSentence){
    	  
    	  if(word.containsKey(wrd)){
    		  word.put(wrd, word.get(wrd) + 1);
    	  }
    	  else{
    		  word.put(wrd, 1);
    	  }
      }
      Set<Entry<String,Integer>> hasM = word.entrySet();
	  System.out.println(hasM); */
 //}

	
	String word2 = "asdfghasdfghasdfgh";
	char [] ch = word2.toCharArray();
	
	HashMap<Character,Integer> charmap =  new LinkedHashMap<Character,Integer>();	
	
	for(Character cha : ch){
		
		if(charmap.containsKey(cha)){
	       charmap.put(cha, charmap.get(cha)+1);		
		}
		else
		{
			charmap.put(cha, 1);
		}
		
	}
	
	Set <Entry<Character,Integer>> hasm = charmap.entrySet(); 	
    //Iterator itr = hasm.iterator();
	System.out.println(hasm);
	}	
	
}

