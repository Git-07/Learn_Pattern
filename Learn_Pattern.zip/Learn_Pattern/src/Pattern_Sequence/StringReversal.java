package Pattern_Sequence;
import java.util.*;

public class StringReversal {
	
	public static void main(String[] a){
	System.out.println("Enter the sentence");
/*	Scanner scan = new Scanner(System.in);
	String sentence = scan.next();*/
	String forward  = "Today is Monday";
	String [] word = forward.split(" ");	
	List<String> words = new ArrayList<String>();
	
			for(int i = word.length-1 ; i>= 0; i--){
				
				words.add(word[i]);
				
			}
			
			for(String backward : words){
				
				System.out.print(backward);
				System.out.print(" ");
			   }
			}

}
