package Pattern_Sequence;
import java.util.*;
public class Name_Reversal_Vowels {
	

	public static void main(String[]  ar){
		
		char[] vowels = {'a','e','i','o','u'};
		Scanner scan = new Scanner(System.in);		
		String word = scan.next();
		char[] words = word.toCharArray();
		int index = 0;
		for(int i = 0 ; i<word.length() ; i++){
			for(int j = 0; j<vowels.length ; j++){
		   	 if(words[i] == vowels[j]){
		   		 index++;		   		 
		   	 }
		     if(index>=1){
		    	 break;
		     }			
			}
		}
		
		if(index>=1){
			
			
		}
		
	}

}
