package Pattern_Sequence;
import java.util.*;
public class Extract_Numeric_From_Alphanumeric {
	
	public static void main(String[] args) throws Exception{
		int sum = 0;
		StringBuffer sfr = new StringBuffer("asdf213546wer");
		String sfr1 = "a%%&&**@@sdf2133333546wer";
		char [] sfr2 = sfr1.toCharArray();
		ArrayList<Integer> intList = new ArrayList<Integer>();
		for(int i =0 ;i<sfr2.length ;i++){
			try{	
			if(Character.isDigit(sfr2[i])){ 
			    intList.add(Character.getNumericValue((sfr2[i]))); //to convert the char value into int
		     //   System.out.print(sfr2[i]);
			}
		}		
			catch(NumberFormatException e){
			 	System.out.println(e);			 
			 }
	}		
		   // System.out.println(intList);
		    for(int in : intList){
		    	sum = sum + in;
		    }
        System.out.println(sum);
		}
	
}
