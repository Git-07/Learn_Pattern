package Pattern_Sequence;

import java.util.*;
// Anagram
public class RotatedVersion {
	
	public static void main(String[] a){
		
		String s1 = "D   ir ty          room";		
		String s2 = "D    or   mitory";
        String  s3 = s1.replaceAll("\\s","");
		String  s4 = s2.replaceAll("\\s","");	
        char [] c1 = s3.toCharArray();
        char [] c2 = s4.toCharArray();
		Arrays.sort(c1);
		Arrays.sort(c2);
		if(Arrays.equals(c1, c2)){
			System.out.println("Equal");
		}
		else{
			System.out.println("not equal");
		}		
	}

}
