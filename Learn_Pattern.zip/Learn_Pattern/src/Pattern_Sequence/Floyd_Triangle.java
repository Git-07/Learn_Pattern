package Pattern_Sequence;
import java.util.*;
public class Floyd_Triangle {

	public static void main(String[] args){
		System.out.println(1);
		Scanner scan = new Scanner(System.in);
		int row = 6;
		//int row= scan.nextInt();
		int nextRow = 1;
		int presentRow = 2;
		int i;
		while(nextRow <= row ){
			for(i=presentRow; i<= presentRow+nextRow;i++){			
				System.out.print(i);				
			}
			presentRow =i;
			System.out.println();
			nextRow++;
		}
		scan.close();
	}
	
}
