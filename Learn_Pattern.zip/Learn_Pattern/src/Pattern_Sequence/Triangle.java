package Pattern_Sequence;
import java.util.*;
public class Triangle {

	public static void main(String[] a){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int row = scan.nextInt();
 int j;
 for(int r = 1 ;r<=row; r++){
	int k=r;
	int x = 0;
    for(j = r ; j<=row-1; j++){    	
    	
    	System.out.print(" ");
    	
    }
    if(r !=1){
    while(x<k*2-1){
    System.out.print("*");
    x++;
    }
    }
    else if(r ==1 ){
    	System.out.print("*");
    }
    System.out.println();
	 
 }
		
	}
}
