package Pattern_Sequence;
import java.util.*;
public class Circular_Printing_Of_Words {
	
	public static void main(String[] args){
		//making sentence or word to rotae from a fixed index
		//String sentence = "Make Selenium Easy Today is Friday and Tommorrow is Saturday";
		String word = "sample";
		Scanner scan = new Scanner(System.in);
		int index = scan.nextInt();
		//int index  = 5;
		//ArrayList<String> list = new ArrayList<String>();
		//String [] newSen = sentence.split("\\s");
		char[] w = word.toCharArray();
		 //below code is for Sentence to printing in circular rotation
		/*  if(index >= 0 && index < newSen.length-1){
			for(int j = index; j<newSen.length;j++){
		     		list.add(newSen[j]);
			}
			  for(int i=0;i<index;i++){
				    list.add(newSen[i]);
				  } 
		   }
		  if(index == newSen.length-1){
			  for(int k = index; k>=0 ;k--){
				  list.add(newSen[k]);
			  }
			  
		  } */
		//below code for a single word to print in rotation
		List<Character> list = new ArrayList<Character>();
		 if(index >= 0 && index < w.length-1){
				for(int j = index; j<w.length;j++){
			     		list.add(w[j]);
				}
				  for(int i=0;i<index;i++){
					    list.add(w[i]);
					  } 
			   }
			  if(index == w.length-1){
				  for(int k = index; k>=0 ;k--){
					  list.add(w[k]);
				  }
				  
			  }

		  Iterator<Character> itr = list.iterator();
		  for(Character s: list){
		  System.out.print(s);
		  //System.out.print(" ");
		  
	}

	}
}
