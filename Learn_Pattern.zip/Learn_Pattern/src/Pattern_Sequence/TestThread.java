package Pattern_Sequence;

class RunnableDemo implements Runnable{
  private Thread t;
  private String threadName;
  
	RunnableDemo(String name){ // paramterised constructor
	    threadName = name;
	    System.out.println("Creating " +  threadName );
	}
   public void run(){ 
	System.out.println("run the thread :" + threadName);
    for(int i= 0; i<4;i++){
    	
    	System.out.println("the threadname : "+ threadName + "running in run method for time :" + i);
    }
}
   public void start(){
	   System.out.println("start the thread :" + threadName);
	   if(t == null){
		   t = new Thread (this, threadName); // this is thread object which is type of Runnable
		   t.start();
	   }
   }  

}
public class TestThread {
	public static void main(String[] a){
	RunnableDemo r1 = new RunnableDemo("Thread One");
	r1.start();
	RunnableDemo r2 = new RunnableDemo("Thread two");
	r2.start();
  }
}