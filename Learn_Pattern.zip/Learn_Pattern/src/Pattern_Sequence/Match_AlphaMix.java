package Pattern_Sequence;
import java.util.*;
public class Match_AlphaMix {
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
		String sentence = scan.next();
		int flag =0;
		String[] regex = {"[a-zA-Z]+","^[a-zA-Z0-9]*$","^[0-9]+"};
        for(int i =0 ; i< regex.length ;i++){
    	   if(sentence.matches(regex[i])){
    		   System.out.println("True");
    		   flag =1;
    		   break;
    	   }
       }
       if(flag == 0){
    	   System.out.println("False");
       }
       scan.close();
	}
}


