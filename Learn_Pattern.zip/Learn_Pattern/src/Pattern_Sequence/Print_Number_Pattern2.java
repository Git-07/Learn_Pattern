package Pattern_Sequence;

public class Print_Number_Pattern2 {
	public static void main(String[] args){
		int row = 6;
		for(int r =1 ;r<=row;r++){

			for(int j = r ; j<row; j++){
				System.out.print(" ");
			}
				  for(int c =1;c<=r ;c++){
				  System.out.print(c);		
				  System.out.print(" ");				    				       
					}				
			System.out.println();
		
		}
	}

}
