package Pattern_Sequence;

public class Moving_A_Particular_Value {
	
	public static void main(String []  ar){
		
		int arr[] = {1,2,9,0,4,5,0,0,7,0,8,6};
		int count = 0;
		int countZero = 0;
		int arrayLen = arr.length;
		for(int i = 0; i < arrayLen ; i++){
			 if(arr[i] != 0){
				arr[count++] = arr[i];
				
			 }
			 else if(arr[i] == 0){
				 ++countZero;
			 }
		}	
		for(int k = arrayLen-countZero; k< arr.length;k++){
			
			arr[k] = 0;
		}
		for(int l = 0; l< arr.length; l++){
			
			System.out.print(arr[l]);
		}
	}
}
