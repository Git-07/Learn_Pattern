package Pattern_Sequence;

import java.util.*;

public class Pattern_Print {
	
	public static void main(String[] nam){	
		Scanner scan = new Scanner(System.in);
		int k = 0;
		System.out.println("Enter the name:");
		
        String name =   scan.next();
		String vowel = "aeiou";
		char [] names = name.toCharArray();	
		char [] vowels = vowel.toCharArray();
		int flag = 0 ;
		int n = 0 ;
		   for(;n<names.length; n++){
			    for(int i = 0 ; i< vowels.length; i++){			    	  
		       if(name.charAt(n) == vowel.charAt(i)){		 
				//  System.out.println("jhdvchjwdcv" + n + name.charAt(n));
				     k = n;
				     flag++; 				     
		   	         }
		          if(flag == 1){
		     	   break;
		         }	       
		     }
		           if(flag == 1){
		     	   break;
		           }
        }
	   
			 char[] newName = new char[k];			
			 char[] afterVowel = new char[names.length - k];	
		    if(k >=0 && flag == 1){
		
					for(int z = 0 ; z<afterVowel.length;z++ ){						
						afterVowel[z] = names[n];
						n++;
						System.out.print(afterVowel[z]);
					}
		    }
	
					if(k>0) {	
					 for(int j = 0 ; j<k; j++){																		
						  newName[j] = names[j];			
								System.out.print(newName[j]);
							}
						
	}
		
		  else if(k==0 && flag ==0){
			  System.out.println("no vowel is found");
		  }
					System.out.print("ay");
		
			}
	
	
}
	

	
	




